package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PantryDatabase
import com.example.data.PantryRepository
import com.example.data.TheMealDbApi
import com.example.ui.PantryViewModel
import com.example.ui.PantryViewModelFactory
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

enum class KitchenTab(val title: String, val icon: ImageVector) {
    Chef("Mi Chef", Icons.Default.Person),
    Pantry("Despensa", Icons.Default.ShoppingCart),
    Suggestions("Recetas", Icons.Default.Favorite),
    Shopping("Compras", Icons.Default.Check),
    History("Logros", Icons.Default.Star),
    Search("Buscador", Icons.Default.Search),
    Dashboard("Dash", Icons.Default.Home)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Core DB + API Injection
        val database = PantryDatabase.getDatabase(applicationContext)
        val repository = PantryRepository(database.pantryDao())
        val api = TheMealDbApi.create()

        setContent {
            // Initialize ViewModel securely using Factory
            val viewModel: PantryViewModel by viewModels {
                PantryViewModelFactory(application, repository, api)
            }
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                var currentTab by remember { mutableStateOf(KitchenTab.Chef) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("main_bottom_navigation"),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(vertical = 10.dp, horizontal = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                KitchenTab.values().forEach { tab ->
                                    val selected = currentTab == tab
                                    val interactionSource = remember { MutableInteractionSource() }
                                    
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(
                                                if (selected) MaterialTheme.colorScheme.primaryContainer 
                                                else Color.Transparent
                                            )
                                            .clickable(
                                                interactionSource = interactionSource,
                                                indication = ripple(),
                                                onClick = { currentTab = tab }
                                            )
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                            .testTag("tab_item_${tab.name.lowercase()}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = tab.icon,
                                                contentDescription = tab.title,
                                                tint = if (selected) MaterialTheme.colorScheme.onPrimaryContainer 
                                                       else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier
                                                    .size(20.dp)
                                                    .testTag("tab_icon_${tab.name.lowercase()}")
                                            )
                                            Text(
                                                text = tab.title,
                                                fontSize = 11.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer 
                                                        else MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    },
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            KitchenTab.Dashboard -> DashboardScreen(viewModel = viewModel)
                            KitchenTab.Chef -> ChefProfileScreen(viewModel = viewModel)
                            KitchenTab.Pantry -> PantryScreen(viewModel = viewModel)
                            KitchenTab.Suggestions -> SuggestionsScreen(viewModel = viewModel)
                            KitchenTab.Shopping -> ShoppingScreen(viewModel = viewModel)
                            KitchenTab.History -> HistoryScreen(viewModel = viewModel)
                            KitchenTab.Search -> WebSearchScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
