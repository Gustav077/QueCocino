package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Meal
import com.example.ui.PantryViewModel

@Composable
fun WebSearchScreen(
    viewModel: PantryViewModel,
    modifier: Modifier = Modifier
) {
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val searchError by viewModel.searchError.collectAsState()
    val pantryItems by viewModel.pantryItems.collectAsState()
    val chefProfile by viewModel.chefProfile.collectAsState()
    val servingsCount = chefProfile.servingsCount
    val isArgentineMode by viewModel.isArgentineMode.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedMealForDetails by remember { mutableStateOf<Meal?>(null) }
    var mealToPlanDirectly by remember { mutableStateOf<Meal?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        // Header
        Text(
            text = "Explorar Nuevas Recetas",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = if (isArgentineMode) "Busca platos de Argentina con el Chef Inteligente (IA)" else "Busca platillos del recetario internacional de TheMealDB",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Preferencia regional card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🇦🇷",
                        fontSize = 24.sp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Preferencia Cocina Argentina",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Activa recetas criollas y vocabulario argentino (IA).",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }
                }
                Switch(
                    checked = isArgentineMode,
                    onCheckedChange = { viewModel.setArgentineMode(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(if (isArgentineMode) "Ej: empanadas, asado, pastel de papa..." else "Ej: pasta, chicken, chocolate...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("recipe_search_input"),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) }
            )

            Button(
                onClick = { viewModel.searchRecipesWeb(searchQuery) },
                modifier = Modifier.testTag("recipe_search_button")
            ) {
                Text("Buscar")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Body content based on state
        if (isSearching) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        } else if (searchError != null) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text(
                    text = searchError ?: "Ocurrió un error al buscar.",
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else if (searchResults.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Busca recetas para comenzar",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = "Prueba con términos culinarios en inglés para mejores resultados (ej: lemon, soup, cake, tomato).",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(searchResults) { meal ->
                    SearchResultCard(
                        meal = meal,
                        onClick = { selectedMealForDetails = meal },
                        onPlanClick = { mealToPlanDirectly = meal }
                    )
                }
            }
        }

        // Details Popup Dialog (reuse detail dialog layout!)
        selectedMealForDetails?.let { meal ->
            val savedRecipes by viewModel.savedRecipes.collectAsState()
            val isMealSaved = savedRecipes.any { it.idMeal == meal.idMeal }
            RecipeDetailsDialog(
                meal = meal,
                pantry = pantryItems,
                servingsCount = servingsCount,
                chefExperienceLevel = chefProfile.experienceLevel,
                onDismiss = { selectedMealForDetails = null },
                onCook = { selectedServings ->
                    viewModel.cookMeal(meal, selectedServings)
                    selectedMealForDetails = null
                },
                onAddMissingToShoppingList = { selectedServings ->
                    viewModel.addMissingIngredientsToShoppingList(meal, selectedServings)
                },
                onPlanMeal = { chosenDay, chosenIsLunch ->
                    viewModel.planMealForDay(chosenDay, meal.strMeal, meal.strMealThumb, chosenIsLunch)
                },
                isSaved = isMealSaved,
                onSaveToggle = { viewModel.toggleSaveRecipe(meal) }
            )
        }

        mealToPlanDirectly?.let { meal ->
            PlanMealOptionDialog(
                mealName = meal.strMeal,
                onDismiss = { mealToPlanDirectly = null },
                onConfirm = { chosenDay, chosenIsLunch ->
                    viewModel.planMealForDay(chosenDay, meal.strMeal, meal.strMealThumb, chosenIsLunch)
                    mealToPlanDirectly = null
                }
            )
        }
    }
}

@Composable
fun SearchResultCard(
    meal: Meal,
    onClick: () -> Unit,
    onPlanClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("search_result_card_${meal.idMeal}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
        ) {
            AsyncImage(
                model = meal.strMealThumb,
                contentDescription = meal.strMeal,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(120.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp))
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(10.dp)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = meal.strMeal,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${meal.strCategory ?: "Plato"} | ${meal.strArea ?: "Región"}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = { onPlanClick() },
                        modifier = Modifier.testTag("plan_search_card_btn_${meal.idMeal}"),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            modifier = Modifier.size(13.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Planificar 📅", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
