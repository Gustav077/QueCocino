package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.LocalArgentineRecipes
import com.example.data.WeeklyMeal
import com.example.ui.PantryViewModel

data class WeeklyMealDetail(
    val dayName: String,
    val isLunch: Boolean,
    val recipeName: String,
    val imageUrl: String?,
    val isDone: Boolean
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: PantryViewModel,
    modifier: Modifier = Modifier
) {
    val weeklyMeals by viewModel.weeklyMeals.collectAsState()
    val pantryItems by viewModel.pantryItems.collectAsState()
    val shoppingItems by viewModel.shoppingItems.collectAsState()
    val suggestedRecipes by viewModel.suggestedRecipes.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    var selectedPlanningDayAndMeal by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // Pair(dayName, isLunch)
    var selectedMealForDetails by remember { mutableStateOf<WeeklyMealDetail?>(null) }
    
    val pendingShoppingCount = shoppingItems.count { !it.isCompleted }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Mi Menú Semanal",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Planificá almuerzos y cenas organizadamente",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }

                // Actions block
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Theme Preferences Toggle (Light / Dark mode option)
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.8f),
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        modifier = Modifier.testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.Star else Icons.Default.Face,
                            contentDescription = "Cambiar de Tema"
                        )
                    }

                    // Auto-Plan Action
                    IconButton(
                        onClick = { viewModel.autoPlanWeeklyMeals() },
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier.testTag("auto_plan_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Planificar Automáticamente"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Metrics Summary Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Pantry summary card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("pantry_sum_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.ShoppingCart, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "${pantryItems.size}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "En Despensa",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                }

                // Shopping pending summary card
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shopping_sum_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "$pendingShoppingCount",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Por Comprar",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Global Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Calendario Semanal",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )

                if (weeklyMeals.any { it.lunchName.isNotEmpty() || it.dinnerName.isNotEmpty() }) {
                    TextButton(
                        onClick = { viewModel.clearWeeklyMeals() },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("clear_plan_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Limpiar Todo", fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Main Days List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(weeklyMeals) { meal ->
                    WeeklyDayRowCard(
                        meal = meal,
                        onPlanLunchClick = { selectedPlanningDayAndMeal = Pair(meal.dayName, true) },
                        onPlanDinnerClick = { selectedPlanningDayAndMeal = Pair(meal.dayName, false) },
                        onLunchCardClick = {
                            selectedMealForDetails = WeeklyMealDetail(
                                dayName = meal.dayName,
                                isLunch = true,
                                recipeName = meal.lunchName,
                                imageUrl = meal.lunchImageUrl,
                                isDone = meal.isLunchDone
                            )
                        },
                        onDinnerCardClick = {
                            selectedMealForDetails = WeeklyMealDetail(
                                dayName = meal.dayName,
                                isLunch = false,
                                recipeName = meal.dinnerName,
                                imageUrl = meal.dinnerImageUrl,
                                isDone = meal.isDinnerDone
                            )
                        },
                        onToggleLunchDone = { done -> viewModel.toggleWeeklyMealDone(meal.dayName, true, done) },
                        onToggleDinnerDone = { done -> viewModel.toggleWeeklyMealDone(meal.dayName, false, done) }
                    )
                }
            }
        }

        // Dialog to PLAN meal for a day and type
        if (selectedPlanningDayAndMeal != null) {
            val (dayName, isLunch) = selectedPlanningDayAndMeal!!
            val mealLabel = if (isLunch) "Almuerzo" else "Cena"
            PlanDayMealDialog(
                dayName = "$dayName ($mealLabel)",
                suggestedOptions = suggestedRecipes.map { it.first }.ifEmpty { LocalArgentineRecipes.recipes },
                onDismiss = { selectedPlanningDayAndMeal = null },
                onConfirm = { name, imgUrl ->
                    viewModel.planMealForDay(dayName, name, imgUrl, isLunch)
                    selectedPlanningDayAndMeal = null
                }
            )
        }

        // Details / Actions dialog for an existing plan
        if (selectedMealForDetails != null) {
            val planned = selectedMealForDetails!!
            if (planned.recipeName.isNotEmpty()) {
                val mealLabel = if (planned.isLunch) "Almuerzo" else "Cena"
                AlertDialog(
                    onDismissRequest = { selectedMealForDetails = null },
                    confirmButton = {
                        if (!planned.isDone) {
                            Button(
                                onClick = {
                                    // Complete cook meal logic
                                    viewModel.toggleWeeklyMealDone(planned.dayName, planned.isLunch, true)
                                    // Try to check ingredients deduction from pantry if matched
                                    val matchedMeal = (suggestedRecipes.map { it.first } + LocalArgentineRecipes.recipes)
                                        .find { it.strMeal.lowercase().trim() == planned.recipeName.lowercase().trim() }
                                    if (matchedMeal != null) {
                                        viewModel.cookMeal(matchedMeal, 2)
                                    } else {
                                        viewModel.registerMealCooked(planned.recipeName, planned.imageUrl)
                                    }
                                    selectedMealForDetails = null
                                },
                                modifier = Modifier.testTag("modal_cook_button")
                            ) {
                                Icon(Icons.Default.Check, null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Cocinar Plato")
                            }
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = {
                                viewModel.removeMealFromDay(planned.dayName, planned.isLunch)
                                selectedMealForDetails = null
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.testTag("modal_delete_button")
                        ) {
                            Icon(Icons.Default.Delete, null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Eliminar Plan")
                        }
                    },
                    title = {
                        Text(
                            text = "${planned.dayName} - $mealLabel",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (!planned.imageUrl.isNullOrEmpty()) {
                                AsyncImage(
                                    model = planned.imageUrl,
                                    contentDescription = planned.recipeName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                            }
                            Text(
                                text = planned.recipeName,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (planned.isDone) {
                                    "✨ ¡Este plato ya fue preparado y disfrutado!"
                                } else {
                                    "Planificado para este día. Podés marcarlo como Cocinar para registrar el logro y descontar de tu despensa."
                                },
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }
                )
            } else {
                selectedMealForDetails = null
            }
        }
    }
}

@Composable
fun WeeklyDayRowCard(
    meal: WeeklyMeal,
    onPlanLunchClick: () -> Unit,
    onPlanDinnerClick: () -> Unit,
    onLunchCardClick: () -> Unit,
    onDinnerCardClick: () -> Unit,
    onToggleLunchDone: (Boolean) -> Unit,
    onToggleDinnerDone: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("day_card_${meal.dayName.lowercase()}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Day title block
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = meal.dayName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                val mealsCount = (if (meal.lunchName.isNotEmpty()) 1 else 0) + (if (meal.dinnerName.isNotEmpty()) 1 else 0)
                val doneCount = (if (meal.isLunchDone) 1 else 0) + (if (meal.isDinnerDone) 1 else 0)
                
                if (mealsCount > 0) {
                    Text(
                        text = "$doneCount/$mealsCount listos",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (doneCount == mealsCount) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier
                            .background(
                                color = if (doneCount == mealsCount) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(20.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ALMUERZO Row Block
            val isLight = MaterialTheme.colorScheme.primary != Color(0xFF85D7AD)
            MealItemRow(
                label = "Almuerzo",
                badgeColor = if (isLight) Color(0xFFFFF3E0) else Color(0xFF3E2723),
                badgeTextColor = if (isLight) Color(0xFFE65100) else Color(0xFFFFB74D),
                recipeName = meal.lunchName,
                imageUrl = meal.lunchImageUrl,
                isDone = meal.isLunchDone,
                onPlanClick = onPlanLunchClick,
                onMealClick = onLunchCardClick,
                onToggleDone = onToggleLunchDone,
                dayName = meal.dayName,
                isLunch = true
            )

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 10.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
            )

            // CENA Row Block
            MealItemRow(
                label = "Cena",
                badgeColor = if (isLight) Color(0xFFEDE7F6) else Color(0xFF311B92),
                badgeTextColor = if (isLight) Color(0xFF4A148C) else Color(0xFFD1C4E9),
                recipeName = meal.dinnerName,
                imageUrl = meal.dinnerImageUrl,
                isDone = meal.isDinnerDone,
                onPlanClick = onPlanDinnerClick,
                onMealClick = onDinnerCardClick,
                onToggleDone = onToggleDinnerDone,
                dayName = meal.dayName,
                isLunch = false
            )
        }
    }
}

@Composable
fun MealItemRow(
    label: String,
    badgeColor: Color,
    badgeTextColor: Color,
    recipeName: String,
    imageUrl: String?,
    isDone: Boolean,
    onPlanClick: () -> Unit,
    onMealClick: () -> Unit,
    onToggleDone: (Boolean) -> Unit,
    dayName: String,
    isLunch: Boolean
) {
    val typeKey = if (isLunch) "lunch" else "dinner"
    
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Label Type badge
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = badgeColor,
            modifier = Modifier.width(72.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = badgeTextColor,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Content
        if (recipeName.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onMealClick() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!imageUrl.isNullOrEmpty()) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = recipeName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                }

                Text(
                    text = recipeName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDone) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Checkbox(
                checked = isDone,
                onCheckedChange = onToggleDone,
                colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.testTag("done_checkbox_${dayName.lowercase()}_$typeKey")
            )
        } else {
            // Assign meal slot
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onPlanClick() }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Asignar plato",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                    modifier = Modifier.testTag("plan_empty_${dayName.lowercase()}_$typeKey")
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanDayMealDialog(
    dayName: String,
    suggestedOptions: List<com.example.data.Meal>,
    onDismiss: () -> Unit,
    onConfirm: (String, String?) -> Unit
) {
    var customMealName by remember { mutableStateOf("") }
    var selectedImgUrl by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    if (customMealName.isNotBlank()) {
                        onConfirm(customMealName, selectedImgUrl)
                    }
                },
                enabled = customMealName.isNotBlank(),
                modifier = Modifier.testTag("confirm_plan_dialog_button")
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        },
        title = {
            Text(
                text = "Planificar para $dayName",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Escribí el plato o elegí una sugerencia rápida:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                OutlinedTextField(
                    value = customMealName,
                    onValueChange = { customMealName = it },
                    label = { Text("Nombre del plato") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("plan_meal_name_field")
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (suggestedOptions.isNotEmpty()) {
                    Text(
                        text = "Sugerencias de Recetas:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    // Vertical options list in dialog
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        suggestedOptions.take(5).forEach { meal ->
                            Card(
                                onClick = {
                                    customMealName = meal.strMeal
                                    selectedImgUrl = meal.strMealThumb
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("chip_suggested_${meal.strMeal.lowercase().replace(" ", "_")}"),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (customMealName == meal.strMeal) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    }
                                ),
                                border = if (customMealName == meal.strMeal) {
                                    BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                } else null
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (meal.strMealThumb.isNotEmpty()) {
                                        AsyncImage(
                                            model = meal.strMealThumb,
                                            contentDescription = meal.strMeal,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                    }
                                    Text(
                                        text = meal.strMeal,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}
