package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Organic Orchard Theme Colors - Light Mode
val OrchardPrimaryLight = Color(0xFF1B4332)          // Deep Forest Green
val OrchardOnPrimaryLight = Color(0xFFFFFFFF)
val OrchardPrimaryContainerLight = Color(0xFFD8F3DC) // Nice light pastel mint for container/chips
val OrchardOnPrimaryContainerLight = Color(0xFF1B4332)

val OrchardSecondaryLight = Color(0xFF0E6C4A)        // Vibrant leafy green
val OrchardOnSecondaryLight = Color(0xFFFFFFFF)
val OrchardSecondaryContainerLight = Color(0xFFA0F4C8)
val OrchardOnSecondaryContainerLight = Color(0xFF0E6C4A)

val OrchardBackgroundLight = Color(0xFFF3FBF3)       // Mint White backdrop
val OrchardOnBackgroundLight = Color(0xFF161D19)
val OrchardSurfaceLight = Color(0xFFF3FBF3)
val OrchardOnSurfaceLight = Color(0xFF161D19)
val OrchardSurfaceVariantLight = Color(0xFFDCE5DD)
val OrchardOnSurfaceVariantLight = Color(0xFF414844)
val OrchardOutlineLight = Color(0xFF717973)

// Organic Orchard Theme Colors - Dark Mode
val OrchardPrimaryDark = Color(0xFF85D7AD)           // Pale mint green for dark theme
val OrchardOnPrimaryDark = Color(0xFF003822)
val OrchardPrimaryContainerDark = Color(0xFF1B4332)   // Rich dark forest container
val OrchardOnPrimaryContainerDark = Color(0xFFC2ECD5)

val OrchardSecondaryDark = Color(0xFFA0F4C8)
val OrchardOnSecondaryDark = Color(0xFF003823)
val OrchardSecondaryContainerDark = Color(0xFF005238)
val OrchardOnSecondaryContainerDark = Color(0xFFA0F4C8)

val OrchardBackgroundDark = Color(0xFF0A1B13)        // Deepest forest green floor
val OrchardOnBackgroundDark = Color(0xFFE2E9E4)
val OrchardSurfaceDark = Color(0xFF10271D)           // Dark surface card overlay
val OrchardOnSurfaceDark = Color(0xFFE2E9E4)
val OrchardSurfaceVariantDark = Color(0xFF2C3E34)
val OrchardOnSurfaceVariantDark = Color(0xFFC1C8C2)
val OrchardOutlineDark = Color(0xFF8B938D)
