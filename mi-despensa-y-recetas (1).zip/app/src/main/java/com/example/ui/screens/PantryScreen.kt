package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.data.PantryItem
import com.example.ui.PantryViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun PantryScreen(
    viewModel: PantryViewModel,
    modifier: Modifier = Modifier
) {
    val pantryItems by viewModel.pantryItems.collectAsState()
    val isAnalyzingPhoto by viewModel.isAnalyzingPhoto.collectAsState()
    val scannedProductDraft by viewModel.scannedProductDraft.collectAsState()
    
    var showAddDialog by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    var qtyInput by remember { mutableStateOf("") }
    var selectedUnit by remember { mutableStateOf("unidades") }
    var selectedCategory by remember { mutableStateOf("Verduras") }

    val categories = listOf("Verduras", "Carnes", "Lácteos", "Especias", "Panadería", "Granos/Pastas", "Otros")
    val units = listOf("unidades", "gramos", "kilogramos", "mililitros", "litros")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Mi Despensa",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${pantryItems.size} ingredientes disponibles",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
                
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("add_ingredient_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Añadir")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Añadir")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AI Scanner Entry Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                ),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search, // Utilizing standard icons
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Escáner Inteligente con IA 📸🤖",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Saca una foto de tus alimentos para sumarlos en segundos.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val cameraLauncher = rememberLauncherForActivityResult(
                            contract = ActivityResultContracts.TakePicturePreview()
                        ) { bitmap ->
                            if (bitmap != null) {
                                viewModel.scanProductBitmap(bitmap)
                            }
                        }
                        
                        Button(
                            onClick = { cameraLauncher.launch(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Saca Foto", fontSize = 13.sp)
                        }
                        
                        var showPresetsDialog by remember { mutableStateOf(false) }
                        
                        OutlinedButton(
                            onClick = { showPresetsDialog = true },
                            modifier = Modifier.weight(1.3f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simular Alimento 🇦🇷", fontSize = 13.sp)
                        }
                        
                        if (showPresetsDialog) {
                            PresetsScanDialog(
                                onDismiss = { showPresetsDialog = false },
                                onPresetSelected = { productName ->
                                    viewModel.scanSimulatedProduct(productName)
                                    showPresetsDialog = false
                                }
                            )
                        }
                    }
                }
            }

            if (pantryItems.isEmpty()) {
                // Empty state beautiful cue
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(30.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(56.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Tu despensa está vacía",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Carga lo que tienes en tu refrigerador o alacena para comenzar a sugerirte recetas ricas.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = { showAddDialog = true }) {
                        Text("Cargar mi Primer Ingrediente")
                    }
                }
            } else {
                // Ingredients List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(pantryItems, key = { it.id }) { item ->
                        PantryItemCard(
                            item = item,
                            onQtyChange = { newQty -> viewModel.updatePantryItemQty(item, newQty) },
                            onDelete = { viewModel.deletePantryItem(item) }
                        )
                    }
                }
            }
        }

        // Add Ingredient Dialog
        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Nuevo Ingrediente") },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { 
                                nameInput = it
                                selectedCategory = com.example.ui.autoCategorizeIngredient(it)
                            },
                            label = { Text("Nombre (ej. Pollo, Tomate)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ingredient_name_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = qtyInput,
                                onValueChange = { qtyInput = it },
                                label = { Text("Cantidad") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ingredient_qty_input")
                            )

                            // Units selection dropdown simplified via row selector or menu
                            Box(modifier = Modifier.weight(1f)) {
                                var expandedUnits by remember { mutableStateOf(false) }
                                OutlinedButton(
                                    onClick = { expandedUnits = true },
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                                ) {
                                    Text(selectedUnit, fontSize = 12.sp)
                                    Icon(Icons.Default.ArrowDropDown, null)
                                }
                                DropdownMenu(
                                    expanded = expandedUnits,
                                    onDismissRequest = { expandedUnits = false }
                                ) {
                                    units.forEach { u ->
                                        DropdownMenuItem(
                                            text = { Text(u) },
                                            onClick = {
                                                selectedUnit = u
                                                expandedUnits = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Category Selection flow
                        Text("Categoría:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            categories.forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val parsedQty = qtyInput.toDoubleOrNull() ?: 1.0
                            if (nameInput.isNotBlank()) {
                                viewModel.addPantryItem(
                                    name = nameInput,
                                    quantity = parsedQty,
                                    unit = selectedUnit,
                                    category = selectedCategory
                                )
                                // Reset fields
                                nameInput = ""
                                qtyInput = ""
                                selectedUnit = "unidades"
                                selectedCategory = "Verduras"
                                showAddDialog = false
                            }
                        },
                        modifier = Modifier.testTag("submit_ingredient_button")
                    ) {
                        Text("Guardar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }

        // Photo loading dialog
        if (isAnalyzingPhoto) {
            AlertDialog(
                onDismissRequest = {},
                properties = androidx.compose.ui.window.DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false
                ),
                title = { Text("Escaneando Alimento... 🤖") },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Analizando la foto con Inteligencia Artificial.\nEsto tomará unos segundos...",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp
                        )
                    }
                },
                confirmButton = {}
            )
        }

        // Draft modification and review dialog
        scannedProductDraft?.let { draft ->
            DraftReviewDialog(
                draft = draft,
                onUpdateDraft = { name, qty, unit, category ->
                    viewModel.updateScannedDraft(name, qty, unit, category)
                },
                onConfirm = {
                    viewModel.commitScannedDraft()
                },
                onDismiss = {
                    viewModel.clearScannedDraft()
                }
            )
        }
    }
}

@Composable
fun PresetsScanDialog(
    onDismiss: () -> Unit,
    onPresetSelected: (String) -> Unit
) {
    val presets = listOf(
        Pair("Yerba Mate Taragüi 500g 🧉", "Yerba Mate"),
        Pair("Dulce de Leche La Serenísima 🍯", "Dulce de Leche"),
        Pair("Bife de Chorizo de Carnicería 🥩", "Bife de Chorizo"),
        Pair("Tapas de Empanadas La Salteña 🥟", "Tapas de Empanadas"),
        Pair("Polenta Presto Pronta de Maíz 🌽", "Polenta No Quiere")
    )
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Simular Escaneo por Foto") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Seleccioná un producto de simulación típico para ver la IA en acción:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                presets.forEach { (label, rawVal) ->
                    Button(
                        onClick = { onPresetSelected(rawVal) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(label, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DraftReviewDialog(
    draft: com.example.data.RecognizedProduct,
    onUpdateDraft: (String, Double, String, String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    var nameEdit by remember { mutableStateOf(draft.nombre) }
    var qtyEdit by remember { mutableStateOf(draft.cantidad.toString()) }
    var unitEdit by remember { mutableStateOf(draft.unidad) }
    var categoryEdit by remember { mutableStateOf(draft.categoria) }

    val categories = listOf("Verduras", "Carnes", "Lácteos", "Especias", "Panadería", "Granos/Pastas", "Otros")
    val units = listOf("unidades", "gramos", "kilogramos", "mililitros", "litros")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Check, 
                    contentDescription = null, 
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("¡Alimento Detectado! 🎉🤖")
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "A continuación podés corregir o modificar el nombre, la cantidad, unidad o categoría antes de agregarlo definitivamente:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                OutlinedTextField(
                    value = nameEdit,
                    onValueChange = { nameEdit = it },
                    label = { Text("Nombre del Alimento") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("scanned_name_edit")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = qtyEdit,
                        onValueChange = { qtyEdit = it },
                        label = { Text("Cantidad") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("scanned_qty_edit")
                    )

                    // Units selector Dropdown
                    Box(modifier = Modifier.weight(1f)) {
                        var expandedUnits by remember { mutableStateOf(false) }
                        OutlinedButton(
                            onClick = { expandedUnits = true },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            Text(unitEdit, fontSize = 12.sp)
                            Icon(Icons.Default.ArrowDropDown, null)
                        }
                        DropdownMenu(
                            expanded = expandedUnits,
                            onDismissRequest = { expandedUnits = false }
                        ) {
                            units.forEach { u ->
                                DropdownMenuItem(
                                    text = { Text(u) },
                                    onClick = {
                                        unitEdit = u
                                        expandedUnits = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Category Selection row
                Text("Categoría:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = categoryEdit == cat,
                            onClick = { categoryEdit = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedQty = qtyEdit.toDoubleOrNull() ?: 1.0
                    onUpdateDraft(nameEdit, parsedQty, unitEdit, categoryEdit)
                    onConfirm()
                },
                modifier = Modifier.testTag("scanned_confirm_save_button")
            ) {
                Text("Guardar Ingrediente 💾")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("scanned_dismiss_button")
            ) {
                Text("Cerrar")
            }
        }
    )
}

@Composable
fun PantryItemCard(
    item: PantryItem,
    onQtyChange: (Double) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pantry_item_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val badgeColor = when (item.category) {
                        "Carnes" -> Color(0xFFEF9A9A)
                        "Verduras" -> Color(0xFFA5D6A7)
                        "Lácteos" -> Color(0xFF90CAF9)
                        "Especias" -> Color(0xFFFFCC80)
                        "Panadería" -> Color(0xFFD7CCC8)
                        "Granos/Pastas" -> Color(0xFFE6EE9C)
                        else -> MaterialTheme.colorScheme.secondaryContainer
                    }
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(badgeColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Categoría: ${item.category}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            // Interactive Qty controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { onQtyChange(item.quantity - 1) },
                    modifier = Modifier.size(32.dp).testTag("decrease_qty_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Menos",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                
                Text(
                    text = "${if(item.quantity % 1.0 == 0.0) item.quantity.toInt() else item.quantity} ${item.unit}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.testTag("qty_label_${item.id}")
                )

                IconButton(
                    onClick = { onQtyChange(item.quantity + 1) },
                    modifier = Modifier.size(32.dp).testTag("increase_qty_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowUp,
                        contentDescription = "Más",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp).testTag("delete_item_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Eliminar",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}
