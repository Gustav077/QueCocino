package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ChefProfile
import com.example.ui.PantryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChefProfileScreen(
    viewModel: PantryViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.chefProfile.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    
    var nameInput by remember(profile) { mutableStateOf(profile.name) }
    var experienceInput by remember(profile) { mutableStateOf(profile.experienceLevel) }
    var specialtyInput by remember(profile) { mutableStateOf(profile.specialty) }
    var servingsInput by remember(profile) { mutableStateOf(profile.servingsCount) }
    var chosenPhotoUri by remember(profile) { mutableStateOf(profile.photoUri) }
    var isEditing by remember { mutableStateOf(false) }

    // Auto-enter edit mode only once for brand new chefs (Chef Aprendiz)
    var hasAutoEdited by remember { mutableStateOf(false) }
    if (profile.name == "Chef Aprendiz" && !hasAutoEdited) {
        isEditing = true
        hasAutoEdited = true
    }

    val imageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            chosenPhotoUri = it.toString()
        }
    }

    val experienceLevels = listOf("Principiante", "Amateur", "Sous Chef", "Chef Ejecutivo")
    val specialtyOptions = listOf("Casera", "Italiana", "Saludable", "Pastelería", "Rápida y Fácil")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hero Card (Profile Badge)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            shape = RoundedCornerShape(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                     // Chef Icon / Avatar Badge
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.background)
                            .border(3.dp, MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val displayPhotoUri = if (isEditing) chosenPhotoUri else profile.photoUri
                        val correctedModel = remember(displayPhotoUri) {
                            if (displayPhotoUri.isNullOrBlank()) {
                                null
                            } else if (displayPhotoUri.startsWith("/")) {
                                "file://$displayPhotoUri"
                            } else {
                                displayPhotoUri
                            }
                        }
                        if (correctedModel != null) {
                            AsyncImage(
                                model = correctedModel,
                                contentDescription = "Foto de Chef",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Face,
                                contentDescription = "Avatar de Chef",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(64.dp)
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = profile.name,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("chef_name_display")
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Nivel",
                            tint = Color.Yellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Rango: ${profile.experienceLevel}",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Especialidad",
                            tint = Color.Red,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Especialidad: ${profile.specialty}",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
                        )
                    }
                    

                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isEditing) {
            // Edit Card Profile
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Editar Perfil del Chef",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Nombre del Chef") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chef_name_input"),
                        singleLine = true
                    )

                    // Foto de perfil
                    Text("Foto de Perfil del Chef 📸", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { imageLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier.weight(1f).testTag("pick_chef_photo_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Subir de Galería", fontSize = 11.sp)
                        }

                        if (chosenPhotoUri != null) {
                            TextButton(
                                onClick = { chosenPhotoUri = null },
                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("Remover", fontSize = 11.sp)
                            }
                        }
                    }

                    // Sin fotos preestablecidas, solo subida de galería personalizada

                    // Experience Level Dropdown Selector / Radio Grid
                    Text("Nivel de Experiencia", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        experienceLevels.take(2).forEach { level ->
                            FilterChip(
                                selected = experienceInput == level,
                                onClick = { experienceInput = level },
                                label = { Text(level) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        experienceLevels.drop(2).take(2).forEach { level ->
                            FilterChip(
                                selected = experienceInput == level,
                                onClick = { experienceInput = level },
                                label = { Text(level) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Specialty
                    Text("Especialidad Culinaria", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        specialtyOptions.forEach { spec ->
                            FilterChip(
                                selected = specialtyInput == spec,
                                onClick = { specialtyInput = spec },
                                label = { Text(spec) }
                            )
                        }
                    }

                    // Cooking Servings (Comensales)
                    Text("¿Para cuántas personas cocinás normalmente?", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val servingsOptions = listOf(1, 2, 4, 6)
                        // First group of 2
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            servingsOptions.take(2).forEach { count ->
                                val label = when(count) {
                                    1 -> "Para mí (1)"
                                    2 -> "Pareja (2)"
                                    else -> "$count"
                                }
                                FilterChip(
                                    selected = servingsInput == count,
                                    onClick = { servingsInput = count },
                                    label = { Text(label, maxLines = 1) },
                                    modifier = Modifier.weight(1f),
                                    leadingIcon = if (servingsInput == count) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null
                                )
                            }
                        }
                        // Second group of 2
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            servingsOptions.drop(2).take(2).forEach { count ->
                                val label = when(count) {
                                    4 -> "Para 4 personas (4)"
                                    6 -> "4 o más (Grupo 6+)"
                                    else -> "$count"
                                }
                                FilterChip(
                                    selected = servingsInput == count,
                                    onClick = { servingsInput = count },
                                    label = { Text(label, maxLines = 1) },
                                    modifier = Modifier.weight(1f),
                                    leadingIcon = if (servingsInput == count) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null
                                )
                            }
                        }
                    }

                    // Subtitle explaining servings logic
                    Text(
                        text = "💡 Las cantidades se adaptarán: si cocinás para 1 persona se reduce la medida; si es para 2, sabrás exactamente cuánto duplicar (x2); para 4 es estándar; y para más de 4 se escala automáticamente al grupo.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    // Bottom Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = {
                            nameInput = profile.name
                            experienceInput = profile.experienceLevel
                            specialtyInput = profile.specialty
                            servingsInput = profile.servingsCount
                            chosenPhotoUri = profile.photoUri
                            isEditing = false
                        }) {
                            Text("Cancelar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.updateChefProfile(
                                    name = nameInput.ifBlank { "Chef" },
                                    experienceLevel = experienceInput,
                                    specialty = specialtyInput,
                                    servingsCount = servingsInput,
                                    photoUri = chosenPhotoUri
                                )
                                isEditing = false
                            },
                            modifier = Modifier.testTag("save_profile_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Guardar")
                        }
                    }
                }
            }
        } else {
            // General Details and Welcomes
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "¡Hola Chef ${profile.name}! Bienvenido a tu cuartel general.",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Carga los ingredientes disponibles en 'Mi Despensa' y deja que preparemos sugerencias personalizadas basadas en tu especialidad y rango de experiencia.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { isEditing = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_profile_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Editar")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Configurar mi Cocina")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.CheckCircle else Icons.Default.Face,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Tema Oscuro",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isDarkMode) "Tema oscuro activo" else "Tema claro activo",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    }
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("chef_theme_switch")
                    )
                }
            }
        }
    }
}
