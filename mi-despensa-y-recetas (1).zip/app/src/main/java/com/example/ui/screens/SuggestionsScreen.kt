package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.Meal
import com.example.data.PantryItem
import com.example.data.LocalArgentineRecipes
import com.example.ui.PantryViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuggestionsScreen(
    viewModel: PantryViewModel,
    modifier: Modifier = Modifier
) {
    val suggestedRecipes by viewModel.suggestedRecipes.collectAsState()
    val isAnalyzing by viewModel.isAnalyzingSuggestions.collectAsState()
    val pantryItems by viewModel.pantryItems.collectAsState()
    val chefProfile by viewModel.chefProfile.collectAsState()
    val servingsCount = chefProfile.servingsCount
    val isArgentineMode by viewModel.isArgentineMode.collectAsState()
    val savedRecipes by viewModel.savedRecipes.collectAsState()

    var selectedMealForDetails by remember { mutableStateOf<Meal?>(null) }
    var mealToPlanDirectly by remember { mutableStateOf<Meal?>(null) }
    var showOnlySaved by remember { mutableStateOf(false) }

    val savedWithScores = remember(savedRecipes, pantryItems) {
        val pantryItemsSet = pantryItems.map { it.name.lowercase().trim() }.toSet()
        savedRecipes.map { meal ->
            val recipeIngredients = meal.getIngredientsList().map { it.first.lowercase().trim() }
            var matchesCount = 0
            for (recIng in recipeIngredients) {
                val hasMatch = pantryItemsSet.any { pantIng ->
                    recIng.contains(pantIng) || pantIng.contains(recIng)
                }
                if (hasMatch) matchesCount++
            }
            val score = if (recipeIngredients.isNotEmpty()) {
                matchesCount.toDouble() / recipeIngredients.size.toDouble()
            } else 0.0
            Pair(meal, score)
        }.sortedByDescending { it.second }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Text(
                text = if (showOnlySaved) "Mi Recetario Personal" else "Sugerencias Inteligentes",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = if (showOnlySaved) "Tus recetas importadas y guardadas localmente" else "Recetas sugeridas con lo que tienes en tu Despensa",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Preferencia regional card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🇦🇷",
                            fontSize = 24.sp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Preferencia Cocina Argentina",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Usa IA para traducir ingredientes y sugerir platos regionales.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                    Switch(
                        checked = isArgentineMode,
                        onCheckedChange = { viewModel.setArgentineMode(it) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Option C: Tab Chips Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !showOnlySaved,
                    onClick = { showOnlySaved = false },
                    label = { Text("Recomendadas", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Favorite, null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("chip_recommended")
                )
                FilterChip(
                    selected = showOnlySaved,
                    onClick = { showOnlySaved = true },
                    label = { Text("Mi Recetario (${savedRecipes.size})", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Star, null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("chip_my_recipes")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (showOnlySaved) {
                // Render Saved Recipes
                if (savedRecipes.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Tu Recetario está vacío",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Explorá ideas en el 'Buscador' o tocá las recetas recomendadas y presioná el botón de corazón ❤️ (Guardar) para agregarlas permanentemente acá.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(savedWithScores) { (meal, matchPercentage) ->
                            RecipeMatchCard(
                                meal = meal,
                                matchPercentage = matchPercentage,
                                pantry = pantryItems,
                                chefExperienceLevel = chefProfile.experienceLevel,
                                onClick = { selectedMealForDetails = meal },
                                onPlanClick = { mealToPlanDirectly = meal }
                            )
                        }
                    }
                }
            } else {
                // Smart Suggestions
                if (pantryItems.isEmpty()) {
                    // Empty state
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Sin ingredientes en la Despensa",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Primero debes añadir ingredientes en la pestaña 'Despensa' para cruzar información y recomendarte platillos adecuados.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                } else if (isAnalyzing) {
                    // Loading spinner
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (isArgentineMode) "Buscando recetas criollas con Chef Inteligente (IA)..." else "Cruzando despensa con recetario web...",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )
                    }
                } else if (suggestedRecipes.isEmpty()) {
                    // No results
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No encontramos coincidencias",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Prueba agregando ingredientes más comunes como: Pollo, Arroz, Papas, Huevo, Tomates o Carne a tu despensa.",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(suggestedRecipes) { (meal, matchPercentage) ->
                            RecipeMatchCard(
                                meal = meal,
                                matchPercentage = matchPercentage,
                                pantry = pantryItems,
                                chefExperienceLevel = chefProfile.experienceLevel,
                                onClick = { selectedMealForDetails = meal },
                                onPlanClick = { mealToPlanDirectly = meal }
                            )
                        }
                    }
                }
            }
        }

        // Details Popup Dialog
        selectedMealForDetails?.let { meal ->
            val savedRecipes by viewModel.savedRecipes.collectAsState()
            val isMealSaved = savedRecipes.any { it.idMeal == meal.idMeal }
            RecipeDetailsDialog(
                meal = meal,
                pantry = pantryItems,
                servingsCount = servingsCount,
                chefExperienceLevel = chefProfile.experienceLevel,
                onDismiss = { selectedMealForDetails = null },
                onCook = { selectedServings ->
                    viewModel.cookMeal(meal, selectedServings)
                    selectedMealForDetails = null
                },
                onAddMissingToShoppingList = { selectedServings ->
                    viewModel.addMissingIngredientsToShoppingList(meal, selectedServings)
                },
                onPlanMeal = { chosenDay, chosenIsLunch ->
                    viewModel.planMealForDay(chosenDay, meal.strMeal, meal.strMealThumb, chosenIsLunch)
                },
                isSaved = isMealSaved,
                onSaveToggle = { viewModel.toggleSaveRecipe(meal) }
            )
        }

        mealToPlanDirectly?.let { meal ->
            PlanMealOptionDialog(
                mealName = meal.strMeal,
                onDismiss = { mealToPlanDirectly = null },
                onConfirm = { chosenDay, chosenIsLunch ->
                    viewModel.planMealForDay(chosenDay, meal.strMeal, meal.strMealThumb, chosenIsLunch)
                    mealToPlanDirectly = null
                }
            )
        }
    }
}

@Composable
fun RecipeMatchCard(
    meal: Meal,
    matchPercentage: Double,
    pantry: List<PantryItem>,
    chefExperienceLevel: String = "Amateur",
    onClick: () -> Unit,
    onPlanClick: () -> Unit
) {
    val scorePercent = (matchPercentage * 100).toInt()
    val progressColor = when {
        scorePercent >= 80 -> Color(0xFF4F7942) // Highly realizable (Olive green)
        scorePercent >= 40 -> Color(0xFFE6B800) // Medium (Honey yellow)
        else -> MaterialTheme.colorScheme.primary // Low
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("recipe_match_card_${meal.idMeal}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(145.dp)
        ) {
            // Recipe Image
            AsyncImage(
                model = meal.strMealThumb,
                contentDescription = meal.strMeal,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(120.dp)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp))
            )

            // Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(12.dp)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = meal.strMeal,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "${meal.strCategory ?: "Platillo"} | ${meal.strArea ?: "Región"}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        
                        // Level Badge
                        val levelBadgeText = if (meal.idMeal.startsWith("gem_")) {
                            chefExperienceLevel
                        } else {
                            LocalArgentineRecipes.metadataMap[meal.idMeal]?.difficulty ?: "Amateur"
                        }
                        
                        Box(
                            modifier = Modifier
                                .background(
                                    color = when (levelBadgeText.lowercase().trim()) {
                                        "principiante" -> Color(0xFFE8F5E9)
                                        "amateur" -> Color(0xFFE3F2FD)
                                        "sous chef" -> Color(0xFFFFF3E0)
                                        "chef ejecutivo" -> Color(0xFFF3E5F5)
                                        else -> Color(0xFFECEFF1)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = when (levelBadgeText.lowercase().trim()) {
                                    "principiante" -> "🔰 $levelBadgeText"
                                    "amateur" -> "🍳 $levelBadgeText"
                                    "sous chef" -> "🌟 $levelBadgeText"
                                    "chef ejecutivo" -> "👑 $levelBadgeText"
                                    else -> "✨ $levelBadgeText"
                                },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (levelBadgeText.lowercase().trim()) {
                                    "principiante" -> Color(0xFF2E7D32)
                                    "amateur" -> Color(0xFF1565C0)
                                    "sous chef" -> Color(0xFFE65100)
                                    "chef ejecutivo" -> Color(0xFF4A148C)
                                    else -> Color(0xFF37474F)
                                }
                            )
                        }
                    }
                }

                Column {
                    // Match visual bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Coincidencia: $scorePercent%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = progressColor
                        )
                        val totalIngredientsCount = meal.getIngredientsList().size
                        Text(
                            text = "Ingred: $totalIngredientsCount",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    LinearProgressIndicator(
                        progress = { matchPercentage.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = progressColor,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { onPlanClick() },
                            modifier = Modifier.testTag("plan_card_btn_${meal.idMeal}"),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Planificar 📅", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// Helper to dynamically adjust culinary measurements relative to standard 4-serving recipes
fun scaleMeasure(measure: String, servingsCount: Int): String {
    if (measure.isBlank()) return ""
    val factor = servingsCount / 4.0
    val regex = Regex("""(\d+/\d+)|\b(\d+(?:\.\d+)?)\b""")
    return regex.replace(measure) { matchResult ->
        val fraction = matchResult.groups[1]?.value
        val number = matchResult.groups[2]?.value
        try {
            val originalVal = if (fraction != null) {
                val parts = fraction.split("/")
                parts[0].toDouble() / parts[1].toDouble()
            } else {
                number?.toDouble() ?: 0.0
            }
            val scaledVal = originalVal * factor
            if (scaledVal == 0.0) {
                matchResult.value
            } else if (scaledVal % 1.0 == 0.0) {
                scaledVal.toInt().toString()
            } else if ((scaledVal * 2) % 1.0 == 0.0) {
                if (scaledVal < 1.0) "1/2" else "${scaledVal.toInt()} 1/2"
            } else if ((scaledVal * 4) % 1.0 == 0.0) {
                if (scaledVal < 1.0) {
                    val quarters = (scaledVal * 4).toInt()
                    "$quarters/4"
                } else {
                    "${scaledVal.toInt()} 1/2"
                }
            } else {
                String.format(java.util.Locale.US, "%.1f", scaledVal)
            }
        } catch (e: Exception) {
            matchResult.value
        }
    }
}

// Full screen popup with details, step by step instructions and cross-checking lists
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecipeDetailsDialog(
    meal: Meal,
    pantry: List<PantryItem>,
    servingsCount: Int,
    chefExperienceLevel: String = "Amateur",
    onDismiss: () -> Unit,
    onCook: (Int) -> Unit,
    onAddMissingToShoppingList: (Int) -> Unit,
    onPlanMeal: ((String, Boolean) -> Unit)? = null,
    isSaved: Boolean = false,
    onSaveToggle: (() -> Unit)? = null
) {
    var activeServings by remember { mutableStateOf(servingsCount) }
    var showPlanningOption by remember { mutableStateOf(false) }

    val ingredients = meal.getIngredientsList()
    val scrollState = rememberScrollState()
    
    // Calculate math matches reactively
    val matchedList = remember(activeServings, pantry, ingredients) {
        val list = mutableListOf<String>()
        for ((unitName, measure) in ingredients) {
            val hasMatch = pantry.any { p ->
                unitName.lowercase().contains(p.name.lowercase()) ||
                p.name.lowercase().contains(unitName.lowercase())
            }
            if (hasMatch) {
                val scaledMeasure = scaleMeasure(measure, activeServings)
                val displayMeasure = if (scaledMeasure.isNotBlank()) " ($scaledMeasure)" else ""
                list.add("$unitName$displayMeasure")
            }
        }
        list
    }

    val missingList = remember(activeServings, pantry, ingredients) {
        val list = mutableListOf<String>()
        for ((unitName, measure) in ingredients) {
            val hasMatch = pantry.any { p ->
                unitName.lowercase().contains(p.name.lowercase()) ||
                p.name.lowercase().contains(unitName.lowercase())
            }
            if (!hasMatch) {
                val scaledMeasure = scaleMeasure(measure, activeServings)
                val displayMeasure = if (scaledMeasure.isNotBlank()) " ($scaledMeasure)" else ""
                list.add("$unitName$displayMeasure")
            }
        }
        list
    }

    var addedToShopping by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null, // Custom upper image content instead
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header image
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                ) {
                    AsyncImage(
                        model = meal.strMealThumb,
                        contentDescription = meal.strMeal,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.3f))
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = meal.strMeal,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Save toggle button
                    if (onSaveToggle != null) {
                        FilledTonalIconButton(
                            onClick = onSaveToggle,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .testTag("recipe_detail_save_icon"),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = if (isSaved) Color(0xFFFFEBEE) else Color.Black.copy(alpha = 0.4f)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Guardar",
                                tint = if (isSaved) Color(0xFFE74C3C) else Color.White
                            )
                        }
                    }
                }

                // Portions Selector Card (Interactive instead of static banner)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val portionsLabel = when(activeServings) {
                                1 -> "Solo para mí (1 porción)"
                                2 -> "Pareja / 2 personas"
                                4 -> "Familia estándar (4 porciones)"
                                6 -> "Grupo o reunión (6 porciones)"
                                else -> "$activeServings porciones"
                            }
                            Text(
                                text = "Porciones elegidas: $portionsLabel",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(1, 2, 4, 6).forEach { count ->
                                val label = when(count) {
                                    1 -> "1 Porción"
                                    2 -> "2 Pers."
                                    4 -> "4 Pers."
                                    6 -> "6+ Pers."
                                    else -> "$count"
                                }
                                val isSelected = activeServings == count
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { activeServings = count },
                                    label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        val scalingExplanation = when(activeServings) {
                            1 -> "🍳 Escala individual (1/4 de porción estándar). No hace falta duplicar."
                            2 -> "👥 Escala de Pareja (Multiplicable x2 en comparación con porción única)."
                            4 -> "👨‍👩‍👧‍👦 Escala de Familia estándar (Medida de receta completa)."
                            6 -> "🍲 Escala de Grupo grande (Aumentando cantidades en un 1.5x)."
                            else -> "Escala adaptada para $activeServings personas."
                        }
                        Text(
                            text = scalingExplanation,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Info Rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SuggestionChip(
                        onClick = {},
                        label = { Text(meal.strCategory ?: "Cocina") },
                        icon = { Icon(Icons.Default.Menu, null, modifier = Modifier.size(16.dp)) }
                    )
                    SuggestionChip(
                        onClick = {},
                        label = { Text(meal.strArea ?: "Región") },
                        icon = { Icon(Icons.Default.Place, null, modifier = Modifier.size(16.dp)) }
                    )
                }

                // Ingredients checklist cross check
                Column {
                    Text(
                        text = "Ingredientes Disponibles",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF4F7942)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    if (matchedList.isEmpty()) {
                        Text("No tienes ninguno de los ingredientes listados.", fontSize = 13.sp, color = Color.Gray)
                    } else {
                        matchedList.forEach { ing ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF4F7942), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(ing, fontSize = 14.sp)
                            }
                        }
                    }
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Faltantes",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (missingList.isNotEmpty() && !addedToShopping) {
                            TextButton(
                                onClick = {
                                    onAddMissingToShoppingList(activeServings)
                                    addedToShopping = true
                                },
                                modifier = Modifier.testTag("add_to_shopping_from_details")
                            ) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Anotar todo", fontSize = 12.sp)
                            }
                        } else if (addedToShopping) {
                            Text("¡Anotado en compras!", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    if (missingList.isEmpty()) {
                        Text("¡Tienes todo para cocinar esta receta entera! 🎉", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4F7942))
                    } else {
                        missingList.forEach { ing ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(ing, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                            }
                        }
                    }
                }

                // Chef Custom Advice relative to Active Level
                val tipContent = getChefSectionContent(meal, chefExperienceLevel)
                if (tipContent != null) {
                    val (title, description) = tipContent
                    val isElite = chefExperienceLevel.lowercase().trim() == "sous chef" || chefExperienceLevel.lowercase().trim() == "chef ejecutivo"
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isElite) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isElite) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (chefExperienceLevel.lowercase().trim() == "chef ejecutivo") "👑" else if (chefExperienceLevel.lowercase().trim() == "sous chef") "🌟" else "🍳",
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = title,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isElite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary,
                                    fontSize = 14.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = description,
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Step-by-Step Instructions
                Column {
                    Text(
                        text = "Instrucciones de Preparación",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = meal.strInstructions ?: "Sin instrucciones disponibles.",
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Justify
                    )
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.wrapContentSize(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onPlanMeal != null) {
                    OutlinedButton(
                        onClick = { showPlanningOption = true },
                        modifier = Modifier.testTag("details_plan_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Planificar", fontSize = 13.sp)
                    }
                }

                Button(
                    onClick = { onCook(activeServings) },
                    modifier = Modifier.testTag("cook_done_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("¡Cocinar!")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar")
            }
        }
    )

    // Option Planning Sub-dialog (nested on top to prevent cluttering)
    if (showPlanningOption) {
        var chosenDay by remember { mutableStateOf("Lunes") }
        var chosenIsLunch by remember { mutableStateOf(true) }

        AlertDialog(
            onDismissRequest = { showPlanningOption = false },
            title = {
                Text(
                    text = "Planificar en Inicio",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "¿Para qué día y momento querés programar \"${meal.strMeal}\"?",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Text(
                        text = "Seleccioná el Día:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Days selector
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val listOfDays = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
                        listOfDays.forEach { d ->
                            FilterChip(
                                selected = chosenDay == d,
                                onClick = { chosenDay = d },
                                label = { Text(d, fontSize = 11.sp) },
                                modifier = Modifier.testTag("plan_day_chip_${d.lowercase()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Seleccioná el Momento:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = chosenIsLunch,
                            onClick = { chosenIsLunch = true },
                            label = { Text("Almuerzo ☀️", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.weight(1f).testTag("plan_moment_lunch")
                        )
                        FilterChip(
                            selected = !chosenIsLunch,
                            onClick = { chosenIsLunch = false },
                            label = { Text("Cena 🌙", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.weight(1f).testTag("plan_moment_dinner")
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPlanMeal?.invoke(chosenDay, chosenIsLunch)
                        showPlanningOption = false
                        onDismiss() // Go back to start screen to see it
                    },
                    modifier = Modifier.testTag("confirm_details_plan_button")
                ) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPlanningOption = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun PlanMealOptionDialog(
    mealName: String,
    onDismiss: () -> Unit,
    onConfirm: (String, Boolean) -> Unit
) {
    var chosenDay by remember { mutableStateOf("Lunes") }
    var chosenIsLunch by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Planificar en Inicio 📅",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.primary
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "¿Para qué día y momento querés programar \"$mealName\"?",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                Text(
                    text = "Seleccioná el Día:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                // Days selector
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val listOfDays = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
                    listOfDays.forEach { d ->
                        FilterChip(
                            selected = chosenDay == d,
                            onClick = { chosenDay = d },
                            label = { Text(d, fontSize = 11.sp) },
                            modifier = Modifier.testTag("plan_day_chip_${d.lowercase()}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Seleccioná el Momento:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = chosenIsLunch,
                        onClick = { chosenIsLunch = true },
                        label = { Text("Almuerzo ☀️", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.weight(1f).testTag("plan_moment_lunch")
                    )
                    FilterChip(
                        selected = !chosenIsLunch,
                        onClick = { chosenIsLunch = false },
                        label = { Text("Cena  🌙", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        modifier = Modifier.weight(1f).testTag("plan_moment_dinner")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(chosenDay, chosenIsLunch)
                },
                modifier = Modifier.testTag("confirm_details_plan_button")
            ) {
                Text("Confirmar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

fun getChefSectionContent(meal: Meal, experienceLevel: String): Pair<String, String>? {
    val level = experienceLevel.lowercase().trim()
    val category = meal.strCategory?.lowercase() ?: ""
    val name = meal.strMeal.lowercase()
    
    val isMeat = category.contains("carne") || category.contains("pollo") || category.contains("pescado") ||
                 name.contains("bife") || name.contains("milanesa") || name.contains("asado") || name.contains("lomo") || name.contains("chorizo") || name.contains("estofado")
                 
    val isPasta = category.contains("pasta") || category.contains("fideos") || category.contains("italiana") ||
                  name.contains("ñoquis") || name.contains("talarines") || name.contains("ravioles") || name.contains("malfatti") || name.contains("risotto") || name.contains("polenta")
                  
    val isSweet = category.contains("postre") || category.contains("pastelería") || category.contains("dulce") ||
                  name.contains("flan") || name.contains("torta") || name.contains("pastafrola") || name.contains("alfajor") || name.contains("panqueque")

    return when (level) {
        "principiante" -> Pair(
            "🔰 Tip de Aprendiz",
            "¡No te apures! Lee todos los pasos antes de encender la hornalla. Deja listos todos tus ingredientes picados y medidos en la mesada antes de empezar (técnica de 'mise en place') para cocinar con total tranquilidad y sin estrés."
        )
        "amateur" -> Pair(
            "🍳 Consejo de Cocina Casera",
            "Para un excelente sabor familiar argentino, precalienta siempre tu sartén u olla antes de incorporar las grasas. No escatimes en condimentos tradicionales rioplatenses de calidad como el pimentón dulce, orégano de las sierras, provenzal y un sutil toque de comino."
        )
        "sous chef" -> {
            val tech = when {
                isMeat -> "Sellar bien la pieza a fuego fuerte para generar la costra de reacción de Maillard y retener todos los jugos esenciales. Luego, desglasar los sabores caramelizados del fondo de la sartén vertiendo un generoso chorro de vino Malbec o Cabernet seco de excelente cepa, reduciendo pacientemente a fuego corona hasta lograr un glaseado untuoso."
                isPasta -> "Cocinar la pasta estrictamente al dente (1 minuto menos que el empaque). Transferir directamente a la sartén de la salsa caliente y realizar una enérgica 'mantecatura' (emulsión) agregando un cucharón de agua almidonada de cocción hirviendo, manteca fría en cubos y queso Reggianito o parmesano rallado fino al revés."
                isSweet -> "Para lograr un brillo profesional absoluto, prepara un almíbar a 118°C antes de verter sobre las yemas si haces merengue. Si preparas un flan criollo tradicional, retíralo apenas coagule el centro y refrigéralo con baño maría inverso inmediatamente para evitar que se formen ojos/burbujas en el interior."
                else -> "Practicar un blanqueado rápido de tus vegetales verdes en agua salada al 1% seguida de sumersión en agua de hielo alpino para fijar la clorofila de forma vibrante. Luego, saltearlos suavemente al sartén con manteca clarificada noisette aromática."
            }
            Pair("🌟 Recomendación Técnica Gourmet", tech)
        }
        "chef ejecutivo" -> {
            val tech = when {
                isMeat -> "Someter la proteína a un braseado lento a temperatura ultra baja o inyectar una salmuera sutil enriquecida con bayas de enebro y romero. Para acompañar, elaborar una demi-glace de carne reducida durante 24 horas y montarla con manteca congelada al punto de servir para lograr un brillo espejo de alta fidelidad culinaria."
                isPasta -> "Infusionar el agua de cocción de la pasta con corteza de queso duro estacionado y granos de pimenta tostada. Emulsionar el sofrito sumando toques de oliva extra virgen prensado en frío y aceite ahumado. Servir coronado con tejas crocantes deshidratadas de sardo y micro-brotes frescos."
                isSweet -> "Deconstruir el postre en texturas contrastantes: servir el plato combinando láminas crujientes de caramelo soplado con finos cristales de sal de salinas, quenelles perfectas de dulce de leche casero templado al roble y rematar con sutil aire o espuma emulsionada de cardamomo o frutos nativos."
                else -> "Texturizar el plato jugando con contrastes de geles ácidos, polvos deshidratados y emulsiones templadas. Aplicar un torneado y cortes geométricos de precisión absoluta a los vegetales. Utilizar reducciones ácidas de cítricos pampeanos para equilibrar la densidad del plato."
            }
            Pair("👑 Secreto Técnico de Alta Cocina", tech)
        }
        else -> null
    }
}


