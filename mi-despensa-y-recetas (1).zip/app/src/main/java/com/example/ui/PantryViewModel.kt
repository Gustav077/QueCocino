package com.example.ui

import android.app.Application
import android.net.Uri
import android.graphics.Bitmap
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class PantryViewModel(
    application: Application,
    private val repository: PantryRepository,
    private val api: TheMealDbApi
) : AndroidViewModel(application) {

    // Streams from database
    val pantryItems: StateFlow<List<PantryItem>> = repository.allPantryItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shoppingItems: StateFlow<List<ShoppingItem>> = repository.allShoppingItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mealHistory: StateFlow<List<MealHistory>> = repository.mealHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chefProfile: StateFlow<ChefProfile> = repository.chefProfile
        .map { it ?: ChefProfile() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChefProfile())

    val weeklyMeals: StateFlow<List<WeeklyMeal>> = repository.allWeeklyMeals
        .map { list ->
            val days = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
            days.map { day ->
                list.find { it.dayName == day } ?: WeeklyMeal(dayName = day)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedRecipes: StateFlow<List<Meal>> = repository.allSavedRecipes
        .map { list ->
            list.map { saved ->
                Meal(
                    idMeal = saved.idMeal,
                    strMeal = saved.strMeal,
                    strMealThumb = saved.strMealThumb,
                    strInstructions = saved.strInstructions,
                    strCategory = saved.strCategory,
                    strArea = saved.strArea,
                    strIngredient1 = saved.strIngredient1, strMeasure1 = saved.strMeasure1,
                    strIngredient2 = saved.strIngredient2, strMeasure2 = saved.strMeasure2,
                    strIngredient3 = saved.strIngredient3, strMeasure3 = saved.strMeasure3,
                    strIngredient4 = saved.strIngredient4, strMeasure4 = saved.strMeasure4,
                    strIngredient5 = saved.strIngredient5, strMeasure5 = saved.strMeasure5,
                    strIngredient6 = saved.strIngredient6, strMeasure6 = saved.strMeasure6,
                    strIngredient7 = saved.strIngredient7, strMeasure7 = saved.strMeasure7,
                    strIngredient8 = saved.strIngredient8, strMeasure8 = saved.strMeasure8,
                    strIngredient9 = saved.strIngredient9, strMeasure9 = saved.strMeasure9,
                    strIngredient10 = saved.strIngredient10, strMeasure10 = saved.strMeasure10,
                    strIngredient11 = saved.strIngredient11, strMeasure11 = saved.strMeasure11,
                    strIngredient12 = saved.strIngredient12, strMeasure12 = saved.strMeasure12,
                    strIngredient13 = saved.strIngredient13, strMeasure13 = saved.strMeasure13,
                    strIngredient14 = saved.strIngredient14, strMeasure14 = saved.strMeasure14,
                    strIngredient15 = saved.strIngredient15, strMeasure15 = saved.strMeasure15
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Web Search Results
    private val _searchResults = MutableStateFlow<List<Meal>>(emptyList())
    val searchResults: StateFlow<List<Meal>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError.asStateFlow()

    // Photo Product Scan State & Control
    private val _isAnalyzingPhoto = MutableStateFlow(false)
    val isAnalyzingPhoto: StateFlow<Boolean> = _isAnalyzingPhoto.asStateFlow()

    private val _scannedProductDraft = MutableStateFlow<RecognizedProduct?>(null)
    val scannedProductDraft: StateFlow<RecognizedProduct?> = _scannedProductDraft.asStateFlow()

    fun updateScannedDraft(name: String, quantity: Double, unit: String, category: String) {
        _scannedProductDraft.value = RecognizedProduct(
            nombre = name,
            cantidad = quantity,
            unidad = unit,
            categoria = category
        )
    }

    fun clearScannedDraft() {
        _scannedProductDraft.value = null
    }

    fun commitScannedDraft() {
        val draft = _scannedProductDraft.value ?: return
        addPantryItem(
            name = draft.nombre,
            quantity = draft.cantidad,
            unit = draft.unidad,
            category = draft.categoria
        )
        _scannedProductDraft.value = null
    }

    fun scanProductBitmap(bitmap: Bitmap) {
        viewModelScope.launch {
            _isAnalyzingPhoto.value = true
            _scannedProductDraft.value = null
            try {
                val base64 = withContext(Dispatchers.IO) {
                    val stream = java.io.ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                    android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)
                }
                val result = geminiService.analyzeProductImage(base64)
                _scannedProductDraft.value = result
            } catch (e: Exception) {
                android.util.Log.e("PantryViewModel", "Error scanning product bitmap", e)
            } finally {
                _isAnalyzingPhoto.value = false
            }
        }
    }

    fun scanProductBase64(base64: String) {
        viewModelScope.launch {
            _isAnalyzingPhoto.value = true
            _scannedProductDraft.value = null
            try {
                val result = geminiService.analyzeProductImage(base64)
                _scannedProductDraft.value = result
            } catch (e: Exception) {
                android.util.Log.e("PantryViewModel", "Error scanning product base64", e)
            } finally {
                _isAnalyzingPhoto.value = false
            }
        }
    }

    fun scanSimulatedProduct(productName: String) {
        viewModelScope.launch {
            _isAnalyzingPhoto.value = true
            _scannedProductDraft.value = null
            try {
                val result = geminiService.analyzeSimulatedProduct(productName)
                _scannedProductDraft.value = result
            } catch (e: Exception) {
                android.util.Log.e("PantryViewModel", "Error scanning simulated product", e)
            } finally {
                _isAnalyzingPhoto.value = false
            }
        }
    }

    // Recipe Match Suggestions State
    private val _suggestedRecipes = MutableStateFlow<List<Pair<Meal, Double>>>(emptyList())
    val suggestedRecipes: StateFlow<List<Pair<Meal, Double>>> = _suggestedRecipes.asStateFlow()

    private val _isAnalyzingSuggestions = MutableStateFlow(false)
    val isAnalyzingSuggestions: StateFlow<Boolean> = _isAnalyzingSuggestions.asStateFlow()

    init {
        // Trigger default recipe matching whenever the pantry, chef level, specialty or saved recipes change
        viewModelScope.launch {
            combine(pantryItems, chefProfile, savedRecipes) { items, profile, saved ->
                Triple(items, profile, saved)
            }.collect { (items, profile, _) ->
                generatePantrySuggestions(items, profile.experienceLevel, profile.specialty)
            }
        }
    }

    // Pantry actions
    fun addPantryItem(name: String, quantity: Double, unit: String, category: String) {
        viewModelScope.launch {
            repository.insertPantryItem(
                PantryItem(name = name.trim(), quantity = quantity, unit = unit, category = category)
            )
        }
    }

    fun updatePantryItemQty(item: PantryItem, newQty: Double) {
        viewModelScope.launch {
            if (newQty <= 0) {
                repository.deletePantryItem(item)
            } else {
                repository.updatePantryItem(item.copy(quantity = newQty))
            }
        }
    }

    fun deletePantryItem(item: PantryItem) {
        viewModelScope.launch {
            repository.deletePantryItem(item)
        }
    }

    // Toggle saved recipe (Option C)
    fun toggleSaveRecipe(meal: Meal) {
        viewModelScope.launch {
            val exists = savedRecipes.value.any { it.idMeal == meal.idMeal }
            if (exists) {
                repository.deleteSavedRecipeById(meal.idMeal)
                Toast.makeText(getApplication(), "Receta eliminada de tu colección local 🗑️", Toast.LENGTH_SHORT).show()
            } else {
                repository.insertSavedRecipe(
                    SavedRecipe(
                        idMeal = meal.idMeal,
                        strMeal = meal.strMeal,
                        strMealThumb = meal.strMealThumb,
                        strInstructions = meal.strInstructions,
                        strCategory = meal.strCategory ?: "Casera",
                        strArea = meal.strArea ?: "Argentina",
                        strIngredient1 = meal.strIngredient1, strMeasure1 = meal.strMeasure1,
                        strIngredient2 = meal.strIngredient2, strMeasure2 = meal.strMeasure2,
                        strIngredient3 = meal.strIngredient3, strMeasure3 = meal.strMeasure3,
                        strIngredient4 = meal.strIngredient4, strMeasure4 = meal.strMeasure4,
                        strIngredient5 = meal.strIngredient5, strMeasure5 = meal.strMeasure5,
                        strIngredient6 = meal.strIngredient6, strMeasure6 = meal.strMeasure6,
                        strIngredient7 = meal.strIngredient7, strMeasure7 = meal.strMeasure7,
                        strIngredient8 = meal.strIngredient8, strMeasure8 = meal.strMeasure8,
                        strIngredient9 = meal.strIngredient9, strMeasure9 = meal.strMeasure9,
                        strIngredient10 = meal.strIngredient10, strMeasure10 = meal.strMeasure10,
                        strIngredient11 = meal.strIngredient11, strMeasure11 = meal.strMeasure11,
                        strIngredient12 = meal.strIngredient12, strMeasure12 = meal.strMeasure12,
                        strIngredient13 = meal.strIngredient13, strMeasure13 = meal.strMeasure13,
                        strIngredient14 = meal.strIngredient14, strMeasure14 = meal.strMeasure14,
                        strIngredient15 = meal.strIngredient15, strMeasure15 = meal.strMeasure15
                    )
                )
                Toast.makeText(getApplication(), "¡Receta guardada con éxito en tu base de datos! 💾🍳", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Shopping actions
    fun addShoppingItem(name: String, quantity: Double, unit: String, category: String = "Otros") {
        viewModelScope.launch {
            val finalCategory = if (category == "Otros" || category.isBlank()) {
                autoCategorizeIngredient(name)
            } else {
                category
            }
            repository.insertShoppingItem(
                ShoppingItem(name = name.trim(), quantity = quantity, unit = unit, category = finalCategory)
            )
        }
    }

    fun toggleShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            val nextState = !item.isCompleted
            repository.updateShoppingItem(item.copy(isCompleted = nextState))
        }
    }

    fun deleteShoppingItem(item: ShoppingItem) {
        viewModelScope.launch {
            repository.deleteShoppingItem(item)
        }
    }

    fun clearCompletedShopping() {
        viewModelScope.launch {
            repository.clearCompletedShoppingItems()
        }
    }

    // History actions
    fun registerMealCooked(recipeName: String, imageUrl: String? = null, ingredients: List<String> = emptyList()) {
        viewModelScope.launch {
            repository.insertMealHistory(
                MealHistory(
                    recipeName = recipeName,
                    imageUrl = imageUrl,
                    ingredientsUsed = ingredients.joinToString(", ")
                )
            )
        }
    }

    // Option 1: Smart cooking with unit conversions and automatic serving-based deduction
    fun cookMeal(meal: Meal, portionsUsed: Int) {
        viewModelScope.launch {
            val ingredientsAndMeasures = meal.getIngredientsList()
            val ingredientsList = ingredientsAndMeasures.map { it.first }

            // 1. Insert meal into history
            repository.insertMealHistory(
                MealHistory(
                    recipeName = meal.strMeal,
                    imageUrl = meal.strMealThumb,
                    ingredientsUsed = ingredientsList.joinToString(", ")
                )
            )

            val depletedIngredients = mutableListOf<String>()
            val updatedIngredients = mutableListOf<String>()

            // 2. Smart deduction with unit conversion (e.g. Kg vs g, L vs ml) and portion scaling
            val currentPantry = pantryItems.value
            ingredientsAndMeasures.forEach { (recName, measure) ->
                val matchedPantryItem = currentPantry.find { pant ->
                    recName.lowercase().trim().contains(pant.name.lowercase().trim()) ||
                    pant.name.lowercase().trim().contains(recName.lowercase().trim())
                }

                if (matchedPantryItem != null) {
                    val recipeQty = parseAmountFromMeasure(measure)
                    val recipeUnit = getUnitFromMeasure(measure)
                    
                    // Portions factor compared to baseline of 4-servings recipes (e.g., portionsUsed / 4)
                    val factor = portionsUsed / 4.0
                    val baseRecipeQty = if (recipeQty > 0.0) recipeQty else 1.0
                    val scaledRecipeQty = baseRecipeQty * factor

                    val pUnit = matchedPantryItem.unit.lowercase().trim()

                    val quantityToDeduct = when (pUnit) {
                        "kilogramos" -> {
                            when (recipeUnit) {
                                "kilogramos" -> scaledRecipeQty
                                "gramos" -> scaledRecipeQty / 1000.0
                                else -> 0.15 * factor // Fallback: 150g (0.15 kg) per serving representation
                            }
                        }
                        "gramos" -> {
                            when (recipeUnit) {
                                "gramos" -> scaledRecipeQty
                                "kilogramos" -> scaledRecipeQty * 1000.0
                                else -> 150.0 * factor // Fallback: 150g per serving
                            }
                        }
                        "litros" -> {
                            when (recipeUnit) {
                                "litros" -> scaledRecipeQty
                                "mililitros" -> scaledRecipeQty / 1000.0
                                else -> 0.2 * factor // Fallback: 200ml (0.2 L) per serving
                            }
                        }
                        "mililitros" -> {
                            when (recipeUnit) {
                                "mililitros" -> scaledRecipeQty
                                "litros" -> scaledRecipeQty * 1000.0
                                else -> 200.0 * factor // Fallback: 200ml per serving
                            }
                        }
                        else -> { // "unidades" or custom units
                            scaledRecipeQty
                        }
                    }

                    val remainingQty = matchedPantryItem.quantity - quantityToDeduct
                    if (remainingQty <= 0.01) {
                        repository.deletePantryItem(matchedPantryItem)
                        depletedIngredients.add(matchedPantryItem.name)
                        // Auto add to shopping list when depleted
                        repository.insertShoppingItem(
                            ShoppingItem(
                                name = matchedPantryItem.name,
                                quantity = if (matchedPantryItem.unit.lowercase().contains("gramo")) 500.0 else 1.0,
                                unit = matchedPantryItem.unit,
                                category = matchedPantryItem.category
                            )
                        )
                    } else {
                        // Round to 2 decimals to ensure nice presentation without FP errors
                        val roundedQty = kotlin.math.round(remainingQty * 100.0) / 100.0
                        if (roundedQty <= 0.01) {
                            repository.deletePantryItem(matchedPantryItem)
                            depletedIngredients.add(matchedPantryItem.name)
                            // Auto add to shopping list when depleted
                            repository.insertShoppingItem(
                                ShoppingItem(
                                    name = matchedPantryItem.name,
                                    quantity = if (matchedPantryItem.unit.lowercase().contains("gramo")) 500.0 else 1.0,
                                    unit = matchedPantryItem.unit,
                                    category = matchedPantryItem.category
                                )
                            )
                        } else {
                            repository.updatePantryItem(matchedPantryItem.copy(quantity = roundedQty))
                            updatedIngredients.add("${matchedPantryItem.name} (le quedan $roundedQty ${matchedPantryItem.unit})")
                        }
                    }
                }
            }

            // 3. Informative custom toast alert to the user
            val chefName = chefProfile.value.name.let { if (it == "Chef Aprendiz" || it.isBlank()) "Chef" else it }
            val message = StringBuilder("¡$chefName cargó los cambios! 🍳\n")
            if (depletedIngredients.isNotEmpty()) {
                message.append("🚨 AGOTADO(S): ${depletedIngredients.joinToString(", ")} (¡Se agregaron automáticamente a la Lista de Compras!)")
            } else if (updatedIngredients.isNotEmpty()) {
                message.append("📉 Despensa actualizada con éxito.")
            } else {
                message.append("Ingredientes actualizados correctamente.")
            }
            Toast.makeText(getApplication(), message.toString(), Toast.LENGTH_LONG).show()
        }
    }

    // Option B & C: Smart portion-calibrated shopping list addition with proactive categorization
    fun addMissingIngredientsToShoppingList(meal: Meal, servingsCount: Int) {
        viewModelScope.launch {
            val currentPantry = pantryItems.value
            val ingredientsAndMeasures = meal.getIngredientsList()
            ingredientsAndMeasures.forEach { (ingredientName, measure) ->
                val hasMatch = currentPantry.any { p ->
                    ingredientName.lowercase().trim().contains(p.name.lowercase().trim()) ||
                    p.name.lowercase().trim().contains(ingredientName.lowercase().trim())
                }
                if (!hasMatch) {
                    val rawQty = parseAmountFromMeasure(measure)
                    val rawUnit = getUnitFromMeasure(measure)
                    
                    // Ratio scaling compared to a 4-servings standard
                    val factor = servingsCount / 4.0
                    val finalQty = if (rawQty > 0.0) {
                        val scaled = rawQty * factor
                        kotlin.math.round(scaled * 100.0) / 100.0
                    } else {
                        1.0
                    }
                    val finalUnit = if (rawQty > 0.0) rawUnit else "unidad"
                    
                    repository.insertShoppingItem(
                        ShoppingItem(
                            name = ingredientName,
                            quantity = finalQty,
                            unit = finalUnit,
                            category = autoCategorizeIngredient(ingredientName)
                        )
                    )
                }
            }
        }
    }

    private fun parseAmountFromMeasure(measure: String): Double {
        if (measure.isBlank()) return 0.0
        val regex = Regex("""(\d+/\d+)|\b(\d+(?:\.\d+)?)\b""")
        val matchResult = regex.find(measure) ?: return 0.0
        val fraction = matchResult.groups[1]?.value
        val number = matchResult.groups[2]?.value
        return try {
            if (fraction != null) {
                val parts = fraction.split("/")
                parts[0].toDouble() / parts[1].toDouble()
            } else {
                number?.toDouble() ?: 0.0
            }
        } catch (e: Exception) {
            0.0
        }
    }

    private fun getUnitFromMeasure(measure: String): String {
        val lower = measure.lowercase()
        return when {
            lower.contains("kg") || lower.contains("kilo") || lower.contains("kilogramo") -> "kilogramos"
            lower.contains("ml") || lower.contains("mili") || lower.contains("mililitro") -> "mililitros"
            lower.contains(" l ") || lower.endsWith(" l") || lower.contains("litro") -> "litros"
            lower.contains("g") || lower.contains("gr") || lower.contains("gram") -> "gramos"
            else -> "unidades"
        }
    }

    fun deleteMealHistory(historyId: Int) {
        viewModelScope.launch {
            repository.deleteMealHistoryById(historyId)
        }
    }

    // Profile actions
    fun updateChefProfile(name: String, experienceLevel: String, specialty: String, servingsCount: Int, photoUri: String? = null) {
        viewModelScope.launch {
            val currentPhoto = chefProfile.value.photoUri
            var finalPhotoUri = photoUri ?: currentPhoto

            val isNewPhoto = photoUri != null &&
                    !photoUri.contains("chef_profile_photo_") &&
                    (photoUri.startsWith("content://") || photoUri.startsWith("file://") || photoUri.startsWith("/"))

            if (isNewPhoto) {
                finalPhotoUri = withContext(Dispatchers.IO) {
                    val context = getApplication<Application>()
                    try {
                        val inputStream = if (photoUri!!.startsWith("content://")) {
                            val uri = Uri.parse(photoUri)
                            context.contentResolver.openInputStream(uri)
                        } else {
                            val filePath = photoUri.removePrefix("file://")
                            val sourceFile = File(filePath)
                            if (sourceFile.exists()) sourceFile.inputStream() else null
                        }

                        if (inputStream != null) {
                            // Clean up old custom profile photo files to free space
                            context.filesDir.listFiles()?.forEach { file ->
                                if (file.name.startsWith("chef_profile_photo_") && file.name.endsWith(".jpg")) {
                                    file.delete()
                                }
                            }

                            val newFileName = "chef_profile_photo_${System.currentTimeMillis()}.jpg"
                            val file = File(context.filesDir, newFileName)
                            inputStream.use { input ->
                                FileOutputStream(file).use { output ->
                                    input.copyTo(output)
                                }
                            }
                            "file://" + file.absolutePath
                        } else {
                            photoUri
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        photoUri
                    }
                }
            }

            repository.updateChefProfile(
                ChefProfile(
                    id = 1,
                    name = name.trim(),
                    experienceLevel = experienceLevel,
                    specialty = specialty,
                    servingsCount = servingsCount,
                    photoUri = finalPhotoUri
                )
            )
        }
    }

    fun updateChefPhoto(photoUri: String?) {
        viewModelScope.launch {
            val current = chefProfile.value
            var finalPhotoUri = photoUri

            val isNewPhoto = photoUri != null &&
                    !photoUri.contains("chef_profile_photo_") &&
                    (photoUri.startsWith("content://") || photoUri.startsWith("file://") || photoUri.startsWith("/"))

            if (isNewPhoto) {
                finalPhotoUri = withContext(Dispatchers.IO) {
                    val context = getApplication<Application>()
                    try {
                        val inputStream = if (photoUri!!.startsWith("content://")) {
                            val uri = Uri.parse(photoUri)
                            context.contentResolver.openInputStream(uri)
                        } else {
                            val filePath = photoUri.removePrefix("file://")
                            val sourceFile = File(filePath)
                            if (sourceFile.exists()) sourceFile.inputStream() else null
                        }

                        if (inputStream != null) {
                            // Clean up old custom profile photo files to free space
                            context.filesDir.listFiles()?.forEach { file ->
                                if (file.name.startsWith("chef_profile_photo_") && file.name.endsWith(".jpg")) {
                                    file.delete()
                                }
                            }

                            val newFileName = "chef_profile_photo_${System.currentTimeMillis()}.jpg"
                            val file = File(context.filesDir, newFileName)
                            inputStream.use { input ->
                                FileOutputStream(file).use { output ->
                                    input.copyTo(output)
                                }
                            }
                            "file://" + file.absolutePath
                        } else {
                            photoUri
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        photoUri
                    }
                }
            }

            repository.updateChefProfile(
                current.copy(photoUri = finalPhotoUri)
            )
        }
    }

    private val geminiService = GeminiService()

    private val _isArgentineMode = MutableStateFlow(true)
    val isArgentineMode: StateFlow<Boolean> = _isArgentineMode.asStateFlow()

    fun setArgentineMode(enabled: Boolean) {
        _isArgentineMode.value = enabled
        viewModelScope.launch {
            val profile = chefProfile.value
            generatePantrySuggestions(pantryItems.value, profile.experienceLevel, profile.specialty)
        }
    }

    // Web Search Action (with Argentine-Castellano regionalizing / translation adapters)
    fun searchRecipesWeb(query: String) {
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            _isSearching.value = true
            _searchError.value = null
            try {
                if (_isArgentineMode.value) {
                    // 1. Try to search regional/Argentinian recipes via Gemini
                    val profile = chefProfile.value
                    val aiResults = geminiService.searchArgentineRecipesDirectly(
                        query = query,
                        experienceLevel = profile.experienceLevel,
                        specialty = profile.specialty
                    )
                    if (aiResults.isNotEmpty()) {
                        _searchResults.value = aiResults
                    } else {
                        // 2. Offline Fallback: match locally loaded Spanish/Argentine recipes
                        val matchedLocal = LocalArgentineRecipes.recipes.filter {
                            it.strMeal.lowercase().contains(query.lowercase()) ||
                            it.strInstructions?.lowercase()?.contains(query.lowercase()) == true ||
                            it.getIngredientsList().any { ing -> ing.first.lowercase().contains(query.lowercase()) }
                        }
                        if (matchedLocal.isNotEmpty()) {
                            _searchResults.value = matchedLocal
                        } else {
                            // 3. Fallback: Query web and translate automatically
                            val response = api.searchRecipes(query)
                            val rawMeals = response.meals ?: emptyList()
                            val translatedMeals = rawMeals.map { meal ->
                                geminiService.translateAndRegionalizeMeal(meal)
                            }
                            _searchResults.value = translatedMeals
                        }
                    }
                } else {
                    // Global untranslated database
                    val response = api.searchRecipes(query)
                    _searchResults.value = response.meals ?: emptyList()
                }
            } catch (e: Exception) {
                _searchError.value = "Error al conectar con el recetario: ${e.localizedMessage}"
            } finally {
                _isSearching.value = false
            }
        }
    }

    // Smart Recipes cross-reference calculation
    private suspend fun generatePantrySuggestions(pantryList: List<PantryItem>, experienceLevel: String = "Amateur", specialty: String = "Casera") {
        if (pantryList.isEmpty()) {
            _suggestedRecipes.value = emptyList()
            return
        }

        _isAnalyzingSuggestions.value = true
        try {
            if (_isArgentineMode.value) {
                // 1. Propose custom localized Argentine suggestions with AI
                val pantryIngNames = pantryList.map { it.name }
                val aiSuggestions = geminiService.generateArgentineSuggestionsFromPantry(pantryIngNames, experienceLevel, specialty)
                if (aiSuggestions.isNotEmpty()) {
                    val pantryItemsSet = pantryList.map { it.name.lowercase().trim() }.toSet()
                    val scored = aiSuggestions.map { meal ->
                        val recipeIngredients = meal.getIngredientsList().map { it.first.lowercase().trim() }
                        var matchesCount = 0
                        for (recIng in recipeIngredients) {
                            val hasMatch = pantryItemsSet.any { pantIng ->
                                recIng.contains(pantIng) || pantIng.contains(recIng)
                            }
                            if (hasMatch) matchesCount++
                        }
                        val score = if (recipeIngredients.isNotEmpty()) {
                            matchesCount.toDouble() / recipeIngredients.size.toDouble()
                        } else 0.5
                        Pair(meal, score)
                    }
                    _suggestedRecipes.value = scored
                    return
                }

                // 2. Offline Fallback: local Argentine recipe pool + user-saved custom recipes
                val matchingScores = mutableListOf<Pair<Meal, Double>>()
                val pantryItemsSet = pantryList.map { it.name.lowercase().trim() }.toSet()

                val isBakingSpecialty = specialty.lowercase().trim() == "pastelería"
                val recipePool = (LocalArgentineRecipes.recipes + savedRecipes.value).filter { meal ->
                    if (!isBakingSpecialty && meal.strCategory?.lowercase()?.trim() == "postre") {
                        false
                    } else {
                        true
                    }
                }
                for (meal in recipePool) {
                    val recipeIngredients = meal.getIngredientsList().map { it.first.lowercase().trim() }
                    if (recipeIngredients.isEmpty()) continue

                    var matchesCount = 0
                    for (recIng in recipeIngredients) {
                        val hasMatch = pantryItemsSet.any { pantIng ->
                            recIng.contains(pantIng) || pantIng.contains(recIng)
                        }
                        if (hasMatch) {
                            matchesCount++
                        }
                    }

                    // Base ingredient match score
                    val baseMatchScore = matchesCount.toDouble() / recipeIngredients.size.toDouble()

                    // Match specialty and experience level metadata
                    val metadata = LocalArgentineRecipes.metadataMap[meal.idMeal]
                    val matchesSpecialty = metadata?.specialty?.lowercase()?.trim() == specialty.lowercase().trim() || !meal.idMeal.startsWith("arg_")
                    val matchesDifficulty = metadata?.difficulty?.lowercase()?.trim() == experienceLevel.lowercase().trim() || !meal.idMeal.startsWith("arg_")

                    val specialtyScore = if (matchesSpecialty) 0.5 else 0.0
                    val difficultyScore = if (matchesDifficulty) 0.3 else 0.0

                    val finalScore = baseMatchScore + specialtyScore + difficultyScore
                    matchingScores.add(Pair(meal, finalScore))
                }

                val sorted = matchingScores
                    .sortedByDescending { finalPair -> finalPair.second }
                    .take(15)

                _suggestedRecipes.value = sorted
            } else {
                // Classic global matching
                val keywords = pantryList.map { it.name.lowercase() }.take(5)
                val gatheredMeals = mutableMapOf<String, Meal>()

                for (keyword in keywords) {
                    try {
                        val response = api.searchRecipes(keyword)
                        response.meals?.forEach { meal ->
                            gatheredMeals[meal.idMeal] = meal
                        }
                    } catch (e: Exception) { /* ignore */ }
                }

                if (gatheredMeals.size < 4) {
                    val fallbacks = listOf("soup", "rice", "chicken", "salad")
                    for (fallback in fallbacks) {
                        if (gatheredMeals.size >= 8) break
                        try {
                            val response = api.searchRecipes(fallback)
                            response.meals?.forEach { meal ->
                                gatheredMeals[meal.idMeal] = meal
                            }
                        } catch (e: Exception) { /* ignore */ }
                    }
                }

                val matchingScores = mutableListOf<Pair<Meal, Double>>()
                val pantryItemsSet = pantryList.map { it.name.lowercase().trim() }.toSet()

                for (meal in gatheredMeals.values) {
                    val recipeIngredients = meal.getIngredientsList().map { it.first.lowercase().trim() }
                    if (recipeIngredients.isEmpty()) continue

                    var matchesCount = 0
                    for (recIng in recipeIngredients) {
                        val hasMatch = pantryItemsSet.any { pantIng ->
                            recIng.contains(pantIng) || pantIng.contains(recIng)
                        }
                        if (hasMatch) {
                            matchesCount++
                        }
                    }

                    val score = matchesCount.toDouble() / recipeIngredients.size.toDouble()
                    matchingScores.add(Pair(meal, score))
                }

                val sorted = matchingScores
                    .sortedByDescending { it.second }
                    .take(15)

                _suggestedRecipes.value = sorted
            }
        } catch (e: Exception) {
            // Keep empty or previous
        } finally {
            _isAnalyzingSuggestions.value = false
        }
    }

    // Weekly meals action methods
    fun planMealForDay(day: String, recipeName: String, imageUrl: String?, isLunch: Boolean) {
        viewModelScope.launch {
            val current = weeklyMeals.value.find { it.dayName == day } ?: WeeklyMeal(dayName = day)
            val updated = if (isLunch) {
                current.copy(lunchName = recipeName, lunchImageUrl = imageUrl, isLunchDone = false)
            } else {
                current.copy(dinnerName = recipeName, dinnerImageUrl = imageUrl, isDinnerDone = false)
            }
            repository.updateWeeklyMeal(updated)
        }
    }

    fun toggleWeeklyMealDone(day: String, isLunch: Boolean, isDone: Boolean) {
        viewModelScope.launch {
            val current = weeklyMeals.value.find { it.dayName == day } ?: WeeklyMeal(dayName = day)
            val updated = if (isLunch) {
                current.copy(isLunchDone = isDone)
            } else {
                current.copy(isDinnerDone = isDone)
            }
            repository.updateWeeklyMeal(updated)
        }
    }

    fun removeMealFromDay(day: String, isLunch: Boolean) {
        viewModelScope.launch {
            val current = weeklyMeals.value.find { it.dayName == day } ?: WeeklyMeal(dayName = day)
            val updated = if (isLunch) {
                current.copy(lunchName = "", lunchImageUrl = null, isLunchDone = false)
            } else {
                current.copy(dinnerName = "", dinnerImageUrl = null, isDinnerDone = false)
            }
            repository.updateWeeklyMeal(updated)
        }
    }

    fun autoPlanWeeklyMeals() {
        viewModelScope.launch {
            val pool = _suggestedRecipes.value.map { it.first }.ifEmpty { LocalArgentineRecipes.recipes }
            if (pool.isNotEmpty()) {
                val days = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
                days.forEachIndexed { index, day ->
                    val lunchMeal = pool[(index * 2) % pool.size]
                    val dinnerMeal = pool[(index * 2 + 1) % pool.size]
                    repository.updateWeeklyMeal(
                        WeeklyMeal(
                            dayName = day,
                            lunchName = lunchMeal.strMeal,
                            lunchImageUrl = lunchMeal.strMealThumb,
                            isLunchDone = false,
                            dinnerName = dinnerMeal.strMeal,
                            dinnerImageUrl = dinnerMeal.strMealThumb,
                            isDinnerDone = false
                        )
                    )
                }
            }
        }
    }

    fun clearWeeklyMeals() {
        viewModelScope.launch {
            repository.clearAllWeeklyMeals()
        }
    }

    // Modern theme Preference Toggle
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }
}

class PantryViewModelFactory(
    private val application: Application,
    private val repository: PantryRepository,
    private val api: TheMealDbApi
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PantryViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PantryViewModel(application, repository, api) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

fun autoCategorizeIngredient(name: String): String {
    val clean = name.lowercase().trim()
    
    // Verduras / Frutas / Vegetales
    val vegetables = listOf(
        "cebolla", "papa", "patata", "tomate", "ajo", "zanahoria", "lechuga", "morrón", "pimiento",
        "espinaca", "acelga", "zapallo", "calabaza", "calabacín", "perejil", "albahaca", "choclo", "maíz",
        "verdeo", "puerro", "berenjena", "brócoli", "coliflor", "palta", "aguacate", "limón", "manzana",
        "banana", "plátano", "frutilla", "fresa", "naranja", "pera", "uva", "champiñón", "hongo", "portobello",
        "rúcula", "radicheta"
    )
    
    // Carnes / Aves / Pescados / Mariscos
    val meats = listOf(
        "carne", "pollo", "pescado", "pechuga", "bife", "lomo", "milanesa", "asado", "vacío", "tira", "cerdo",
        "panceta", "bacon", "jamón", "salchicha", "chorizo", "molida", "picada", "atún", "salmón", "langostino",
        "camarón", "marisco", "pavo", "cordero", "bondiola", "matambre"
    )
    
    // Lácteos / QUESOS / Huevos
    val dairy = listOf(
        "queso", "leche", "manteca", "mantequilla", "crema", "yogur", "cremoso", "mozzarella", "parmesano",
        "provolone", "ricota", "ricotta", "huevo"
    )
    
    // Especias / Condimentos / Salsas / Aceites
    val spices = listOf(
        "sal", "pimienta", "orégano", "ají", "pimentón", "comino", "nuez moscada", "aceite", "vinagre",
        "mayonesa", "ketchup", "mostaza", "salsa de soja", "soya", "caldo", "laurel", "romero", "tomillo"
    )
    
    // Panadería / Harinas / Masas
    val bakery = listOf(
        "pan", "harina", "factura", "medialuna", "galletita", "galleta", "bizcocho", "tostada", "prepizza",
        "masa", "hojaldre", "tarta", "empanada", "pan rallado", "rallado"
    )
    
    // Granos / Pastas / Legumbres
    val grains = listOf(
        "arroz", "fideo", "pasta", "lenteja", "garbanzo", "poroto", "frijol", "avena", "tallarín",
        "ñoqui", "ravioles", "sorrentinos", "polenta", "cebada", "trigo", "quinoa"
    )

    return when {
        vegetables.any { clean.contains(it) } -> "Verduras"
        meats.any { clean.contains(it) } -> "Carnes"
        dairy.any { clean.contains(it) } -> "Lácteos"
        spices.any { clean.contains(it) } -> "Especias"
        bakery.any { clean.contains(it) } -> "Panadería"
        grains.any { clean.contains(it) } -> "Granos/Pastas"
        else -> "Otros"
    }
}
