package com.example.data

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

@JsonClass(generateAdapter = true)
data class GeminiInlineData(
    @Json(name = "mimeType") val mimeType: String,
    @Json(name = "data") val data: String
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String? = null,
    @Json(name = "inlineData") val inlineData: GeminiInlineData? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "generationConfig") val generationConfig: GeminiGenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    @Json(name = "responseMimeType") val responseMimeType: String? = null,
    @Json(name = "temperature") val temperature: Double? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>? = null
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }
}

@JsonClass(generateAdapter = true)
data class RecognizedProduct(
    val nombre: String,
    val cantidad: Double,
    val unidad: String,
    val categoria: String
)

class GeminiService {

    suspend fun analyzeProductImage(base64Image: String): RecognizedProduct? {
        val apiKey = getApiKey() ?: return null
        
        val prompt = """
            Identifica el ingrediente o producto alimenticio que aparece en esta imagen. Devuelve el resultado obligatoriamente como un único objeto JSON que contenga las siguientes propiedades:
            - 'nombre': el nombre del ingrediente en español castellano rioplatense (ej. 'Bife de chorizo', 'Harina leudante', 'Dulce de leche', 'Yerba mate', 'Papas', 'Pollo', 'Tomate pintón', 'Cebolla').
            - 'cantidad': una estimación de la cantidad numérica sugerida o por defecto para una unidad/paquete común (ej. 1.0, 500.0, 1.0).
            - 'unidad': la unidad correspondiente (las opciones estándar son: 'unidades', 'gramos', 'kilogramos', 'mililitros', 'litros').
            - 'categoria': la categoría correspondiente (las opciones estándar son obligatoriamente una de estas: 'Verduras', 'Carnes', 'Lácteos', 'Especias', 'Panadería', 'Granos/Pastas', 'Otros').
            
            Retorna UNICAMENTE el objeto JSON que cumpla estas especificaciones, por ejemplo:
            { "nombre": "Yerba Mate", "cantidad": 1.0, "unidad": "unidades", "categoria": "Otros" }
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = prompt),
                        GeminiPart(inlineData = GeminiInlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            ),
            generationConfig = GeminiGenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2
            )
        )

        return try {
            val response = GeminiClient.api.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val cleanedJson = jsonText.trim()
                val obj = JSONObject(cleanedJson)
                RecognizedProduct(
                    nombre = obj.optString("nombre", ""),
                    cantidad = obj.optDouble("cantidad", 1.0),
                    unidad = obj.optString("unidad", "unidades"),
                    categoria = obj.optString("categoria", "Otros")
                )
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e("GeminiService", "Failed to analyze product image", e)
            null
        }
    }

    suspend fun analyzeSimulatedProduct(productName: String): RecognizedProduct? {
        val apiKey = getApiKey() ?: return RecognizedProduct(
            nombre = productName,
            cantidad = if (productName.lowercase().contains("yerba")) 500.0 else if (productName.lowercase().contains("dulce")) 400.0 else if (productName.lowercase().contains("bife")) 1.0 else if (productName.lowercase().contains("tapa")) 12.0 else 1.0,
            unidad = if (productName.lowercase().contains("yerba") || productName.lowercase().contains("dulce")) "gramos" else if (productName.lowercase().contains("bife")) "kilogramos" else "unidades",
            categoria = if (productName.lowercase().contains("dulce")) "Lácteos" else if (productName.lowercase().contains("bife")) "Carnes" else if (productName.lowercase().contains("tapa")) "Panadería" else "Otros"
        )
        
        val prompt = """
            Identifica el ingrediente o producto alimenticio correspondiente a: '$productName'. 
            Devuelve el resultado obligatoriamente como un único objeto JSON que contenga las siguientes propiedades:
            - 'nombre': el nombre del ingrediente exacto en español castellano rioplatense (ej. 'Bife de chorizo', 'Harina leudante', 'Dulce de leche', 'Yerba mate', 'Papas', 'Pollo', 'Tomate pintón', 'Cebolla').
            - 'cantidad': una estimación de la cantidad numérica sugerida o por defecto para una unidad/paquete de '$productName' (por ejemplo, si es Yerba Mate, ponele 500.0 gramos, si es Tapas de Empanadas ponele 12.0 unidades, si es Dulce de Leche ponele 400.0 gramos).
            - 'unidad': la unidad correspondiente (las opciones estándar son: 'unidades', 'gramos', 'kilogramos', 'mililitros', 'litros').
            - 'categoria': la categoría correspondiente (las opciones estándar son obligatoriamente una de estas: 'Verduras', 'Carnes', 'Lácteos', 'Especias', 'Panadería', 'Granos/Pastas', 'Otros').
            
            Retorna UNICAMENTE el objeto JSON que cumpla estas especificaciones, por ejemplo:
            { "nombre": "Yerba Mate", "cantidad": 500.0, "unidad": "gramos", "categoria": "Otros" }
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = prompt)
                    )
                )
            ),
            generationConfig = GeminiGenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2
            )
        )

        return try {
            val response = GeminiClient.api.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val cleanedJson = jsonText.trim()
                val obj = JSONObject(cleanedJson)
                RecognizedProduct(
                    nombre = obj.optString("nombre", productName),
                    cantidad = obj.optDouble("cantidad", 1.0),
                    unidad = obj.optString("unidad", "unidades"),
                    categoria = obj.optString("categoria", "Otros")
                )
            } else {
                RecognizedProduct(productName, 1.0, "unidades", "Otros")
            }
        } catch (e: Exception) {
            Log.e("GeminiService", "Failed to analyze simulated product", e)
            RecognizedProduct(productName, 1.0, "unidades", "Otros")
        }
    }

    private fun getApiKey(): String? {
        val key = BuildConfig.GEMINI_API_KEY
        return if (key.isNullOrBlank() || key.contains("MY_GEMINI_API_KEY") || key == "GEMINI_API_KEY") {
            null
        } else {
            key
        }
    }

    /**
     * Translates and regionalizes a standard Meal from English to Argentine Spanish.
     */
    suspend fun translateAndRegionalizeMeal(meal: Meal): Meal {
        val apiKey = getApiKey() ?: return meal // Fallback if no key

        val originalJson = """
            {
               "strMeal": "${meal.strMeal}",
               "strCategory": "${meal.strCategory ?: ""}",
               "strArea": "${meal.strArea ?: ""}",
               "strInstructions": "${meal.strInstructions?.replace("\n", " ")?.replace("\"", "'") ?: ""}",
               "ingredients": ${meal.getIngredientsList().map { "${it.second} of ${it.first}" }.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }}
            }
        """.trimIndent()

        val systemPrompt = """
            You are an expert chef in Argentina. Your task is to translate and adapt the culinary recipe JSON provided to Argentinian Spanish (Castellano Rioplatense).
            You MUST follow these rules:
            1. Translate the recipe name 'strMeal' to its natural Argentine equivalent (e.g., 'Potato' -> 'Papa', 'Peaches' -> 'Duraznos', 'Pumpkin' -> 'Calabaza / Zapallo', 'Pork' -> 'Cerdo').
            2. Translate and rewrite 'strInstructions' into natural, warm, clear step-by-step instructions in Argentinian Castellano (using 'rehogar', 'mezclar', "pisar las papas" etc.). Keep the formatting clear.
            3. Rewrite ingredients list and translate them to terms used in Argentina (e.g. 'avocado' -> 'palta', 'corn' -> 'choclo / maíz', 'strawberry' -> 'frutilla', 'peach' -> 'durazno', 'butter' -> 'manteca', 'cream' -> 'crema de leche').
            4. Keep 'strArea' as 'Argentina' or the original name in Spanish, and 'strCategory' in Spanish.
            5. Return ONLY a JSON object matching this schema:
               {
                 "strMeal": "Recipe Name in Spanish",
                 "strCategory": "Category in Spanish",
                 "strArea": "Argentina or Original adapted",
                 "strInstructions": "Steps in Spanish...",
                 "ingredients": [
                    {"ing": "Ingrediente en español", "meas": "medida adaptada"}
                 ]
               }
            Do not output any markdown code blocks, just the raw valid JSON object.
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(GeminiPart(text = "Translate this recipe JSON:\n$originalJson"))
                )
            ),
            generationConfig = GeminiGenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.2
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemPrompt))
            )
        )

        return try {
            val response = GeminiClient.api.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val cleanedJson = jsonText.trim()
                val obj = JSONObject(cleanedJson)
                
                // Map back to Meal structure
                val argIngs = obj.getJSONArray("ingredients")
                val ingMaps = mutableListOf<Pair<String, String>>()
                for (i in 0 until argIngs.length()) {
                    val ingObj = argIngs.getJSONObject(i)
                    ingMaps.add(Pair(ingObj.optString("ing"), ingObj.optString("meas")))
                }

                meal.copy(
                    strMeal = obj.optString("strMeal", meal.strMeal),
                    strCategory = obj.optString("strCategory", meal.strCategory),
                    strArea = obj.optString("strArea", meal.strArea),
                    strInstructions = obj.optString("strInstructions", meal.strInstructions),
                    // Set ingredients & measures up to 15
                    strIngredient1 = ingMaps.getOrNull(0)?.first, strMeasure1 = ingMaps.getOrNull(0)?.second,
                    strIngredient2 = ingMaps.getOrNull(1)?.first, strMeasure2 = ingMaps.getOrNull(1)?.second,
                    strIngredient3 = ingMaps.getOrNull(2)?.first, strMeasure3 = ingMaps.getOrNull(2)?.second,
                    strIngredient4 = ingMaps.getOrNull(3)?.first, strMeasure4 = ingMaps.getOrNull(3)?.second,
                    strIngredient5 = ingMaps.getOrNull(4)?.first, strMeasure5 = ingMaps.getOrNull(4)?.second,
                    strIngredient6 = ingMaps.getOrNull(5)?.first, strMeasure6 = ingMaps.getOrNull(5)?.second,
                    strIngredient7 = ingMaps.getOrNull(6)?.first, strMeasure7 = ingMaps.getOrNull(6)?.second,
                    strIngredient8 = ingMaps.getOrNull(7)?.first, strMeasure8 = ingMaps.getOrNull(7)?.second,
                    strIngredient9 = ingMaps.getOrNull(8)?.first, strMeasure9 = ingMaps.getOrNull(8)?.second,
                    strIngredient10 = ingMaps.getOrNull(9)?.first, strMeasure10 = ingMaps.getOrNull(9)?.second,
                    strIngredient11 = ingMaps.getOrNull(10)?.first, strMeasure11 = ingMaps.getOrNull(10)?.second,
                    strIngredient12 = ingMaps.getOrNull(11)?.first, strMeasure12 = ingMaps.getOrNull(11)?.second,
                    strIngredient13 = ingMaps.getOrNull(12)?.first, strMeasure13 = ingMaps.getOrNull(12)?.second,
                    strIngredient14 = ingMaps.getOrNull(13)?.first, strMeasure14 = ingMaps.getOrNull(13)?.second,
                    strIngredient15 = ingMaps.getOrNull(14)?.first, strMeasure15 = ingMaps.getOrNull(14)?.second
                )
            } else {
                meal
            }
        } catch (e: Exception) {
            Log.e("GeminiService", "Failed to translate meal", e)
            meal
        }
    }

    /**
     * Uses Gemini to suggest meals based on what ingredients are available in the user's pantry.
     * Generates regional Argentine and South American meals in Spanish.
     */
    suspend fun generateArgentineSuggestionsFromPantry(pantry: List<String>, experienceLevel: String, specialty: String): List<Meal> {
        val apiKey = getApiKey() ?: return emptyList()

        val pantryStr = pantry.joinToString(", ")
        val difficultyContext = when (experienceLevel.lowercase().trim()) {
            "principiante" -> "Propón recetas extremadamente fáciles, rápidas de preparar, con muy pocos pasos explícitos, utensilios cotidianos y técnicas de cocción básicas aptas para un principiante total en la cocina."
            "amateur" -> "Propón recetas de dificultad media, caseras, tradicionales y familiares, con instrucciones que sigan una preparación casera estándar y cómoda."
            "sous chef" -> "Propón recetas elaboradas con toques gourmet y cierta elegancia. Las instrucciones deben requerir técnicas culinarias intermedias a avanzadas (como reducciones, puntos de cocción específicos, salteados rápidos o sellados), usando tus ingredientes creativamente."
            "chef ejecutivo" -> "Propón recetas de autor sofisticadas, de alta cocina (estilo plato de restaurante de alta gama), que incluyan técnicas profesionales más complejas (emulsiones, reducciones exquisitas, cortes de precisión o infusión de sabores) e instrucciones detalladas con sugerencias de emplatado, decorados, contrastes y presentación profesional."
            else -> "Propón recetas de dificultad casera o familiar estándar de nivel medio."
        }

        val specialtyContext = when (specialty.lowercase().trim()) {
            "italiana" -> "Enfócate fuertemente en dar un estilo italiano a las sugerencias (pastas rioplatenses, salsas tipo tuco, estofado, ñoquis, pizzas, polentas aromáticas o risottos, adaptándolos a los ingredientes disponibles)."
            "saludable" -> "Enfócate fuertemente en platos saludables, de bajo contenido graso, ricos en vegetales, nutritivos y ligeros, utilizando de forma creativa los ingredientes."
            "pastelería" -> "Si los ingredientes lo permiten, elije platos o incluye preparaciones que tengan que ver con postres, panificados, galletitas o dulces de la pastelería tradicional argentina."
            "rápida y fácil" -> "Enfócate en recetas rápidas (menos de 20 o 30 minutos), fáciles, al plato o minutas típicas de bodegón, ideales para preparar con pocos utensilios."
            else -> "Enfócate en platos clásicos de la cocina casera tradicional de hogar."
        }

        val systemPrompt = """
            You are an expert chef specializing in Argentine and regional Southern Cone cuisine. 
            The user will give you a list of ingredients in their pantry.
            The user's chef experience level is: '$experienceLevel'.
            Therefore, you must: $difficultyContext
            
            The user's preferred culinary specialty is: '$specialty'.
            Therefore, you must also adapt the recipes: $specialtyContext
            
            CRITICAL HEALTH & DIETARY RULE:
            If the user's preferred culinary specialty is NOT 'pastelería' and the search or ingredients are for main meals, you MUST NOT suggest any sweet meals, desserts, pastries, baking cakes, or sugary dishes. Maintain focus strictly on savory lunches and dinners.
            
            The recipes proposed MUST differ dramatically based on experience level '$experienceLevel'. It is a critical error to recommend standard basic dishes (like standard simple milanesas) to a 'Chef Ejecutivo', or highly complex gourmet/deconstructed plates to a 'Principiante'.
            - If '$experienceLevel' is 'principiante': Choose very straightforward, quick-to-prepare simple foods. (e.g. Omelette criollo, Fideos con manteca).
            - If '$experienceLevel' is 'amateur': Choose classic comforting traditional family recipes. (e.g. Pastel de papa hogareño, Milanesas con puré).
            - If '$experienceLevel' is 'sous chef': Choose elaborate, elegant regional-gourmet creations requiring intermediate-advanced technical procedures. (e.g. Risotto criollo perfumado al torrontés, Bondiola de cerdo laqueada).
            - If '$experienceLevel' is 'chef ejecutivo': Choose elite avant-garde haute-cuisine dishes with sophisticated techniques like braising, reductions, deconstructions, and professional plating. (e.g. Deconstrucción de pastel de papa al aroma de trufas, Ojo de bife braseado a baja temperatura con demi-glace al Syrah).

            Your task is to propose between 6 and 10 completely diverse, delicious, authentic, and regional dishes (e.g. pastel de papa, guiso, tortilla, empanadas, milanesas, bifes con verduras, etc.) that match this chef's skill level and specialty preference, and can be made using mostly these ingredients (you are allowed to suggest minor staple fallbacks like oil, salt, water, garlic, pepper, oil, flour, baking powder, water).
            
            You MUST follow these strict requirements:
            1. All recipes must be described entirely in Spanish (Castellano rioplatense terms: papa, choclo, morrón, verdeo, etc. to match the user's local Argentine vibe).
            2. For each recipe determine the name (strMeal), category (custom category suitable for the dish), area (should be 'Argentina'), instructions (strInstructions - keep instructions fully tailored to the '$experienceLevel' difficulty context specified above!), and ingredients with appropriate measurements.
            3. Each recipe's strMealThumb must be a high-quality free cooking-related image URL from Unsplash. Try to use realistic Unsplash URLs like:
               - Pastel de papa: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500'
               - Milanesa: 'https://images.unsplash.com/photo-1600891964599-f61ba0e24092?w=500'
               - Guiso: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=500'
               - General steak/pork/chicken: 'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=500'
               - General vegetable/omelette: 'https://images.unsplash.com/photo-1608039755401-742074f0548d?w=500'
               - Dessert/Sweet: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=500'
               Otherwise, put any beautiful food photo from Unsplash.
            4. Return ONLY a valid JSON array of objects (between 6 and 10 items). NO MARKDOWN CODE BLOCKS, NO TRIPLE BACKTICKS.
            The JSON array elements must match this schema:
            [
              {
                "idMeal": "gemini_idx_1",
                "strMeal": "Nombre Criollo / Regional",
                "strMealThumb": "https://images.unsplash.com/photo-...",
                "strCategory": "Guiso o Carne o Casera",
                "strArea": "Argentina",
                "strInstructions": "Instrucciones adaptadas detalladamente para el nivel de un $experienceLevel...",
                "ingredients": [
                   {"ing": "Cebolla", "meas": "1 unidad"},
                   {"ing": "Papa", "meas": "2 unidades"}
                ]
              }
            ]
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(GeminiPart(text = "My pantry ingredients are: $pantryStr"))
                )
            ),
            generationConfig = GeminiGenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.85
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemPrompt))
            )
        )

        return try {
            val response = GeminiClient.api.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val cleanedJson = jsonText.trim()
                val array = JSONArray(cleanedJson)
                val list = mutableListOf<Meal>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val argIngs = obj.getJSONArray("ingredients")
                    val ingMaps = mutableListOf<Pair<String, String>>()
                    for (j in 0 until argIngs.length()) {
                        val ingObj = argIngs.getJSONObject(j)
                        ingMaps.add(Pair(ingObj.optString("ing"), ingObj.optString("meas")))
                    }

                    list.add(
                        Meal(
                            idMeal = obj.optString("idMeal", "gem_suggest_$i"),
                            strMeal = obj.optString("strMeal"),
                            strMealThumb = obj.optString("strMealThumb", "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500"),
                            strInstructions = obj.optString("strInstructions"),
                            strCategory = obj.optString("strCategory", "Casera"),
                            strArea = obj.optString("strArea", "Argentina"),
                            strIngredient1 = ingMaps.getOrNull(0)?.first, strMeasure1 = ingMaps.getOrNull(0)?.second,
                            strIngredient2 = ingMaps.getOrNull(1)?.first, strMeasure2 = ingMaps.getOrNull(1)?.second,
                            strIngredient3 = ingMaps.getOrNull(2)?.first, strMeasure3 = ingMaps.getOrNull(2)?.second,
                            strIngredient4 = ingMaps.getOrNull(3)?.first, strMeasure4 = ingMaps.getOrNull(3)?.second,
                            strIngredient5 = ingMaps.getOrNull(4)?.first, strMeasure5 = ingMaps.getOrNull(4)?.second,
                            strIngredient6 = ingMaps.getOrNull(5)?.first, strMeasure6 = ingMaps.getOrNull(5)?.second,
                            strIngredient7 = ingMaps.getOrNull(6)?.first, strMeasure7 = ingMaps.getOrNull(6)?.second,
                            strIngredient8 = ingMaps.getOrNull(7)?.first, strMeasure8 = ingMaps.getOrNull(7)?.second,
                            strIngredient9 = ingMaps.getOrNull(8)?.first, strMeasure9 = ingMaps.getOrNull(8)?.second,
                            strIngredient10 = ingMaps.getOrNull(9)?.first, strMeasure10 = ingMaps.getOrNull(9)?.second,
                            strIngredient11 = ingMaps.getOrNull(10)?.first, strMeasure11 = ingMaps.getOrNull(10)?.second,
                            strIngredient12 = ingMaps.getOrNull(11)?.first, strMeasure12 = ingMaps.getOrNull(11)?.second,
                            strIngredient13 = ingMaps.getOrNull(12)?.first, strMeasure13 = ingMaps.getOrNull(12)?.second,
                            strIngredient14 = ingMaps.getOrNull(13)?.first, strMeasure14 = ingMaps.getOrNull(13)?.second,
                            strIngredient15 = ingMaps.getOrNull(14)?.first, strMeasure15 = ingMaps.getOrNull(14)?.second
                        )
                    )
                }
                list
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e("GeminiService", "Failed to generate suggestions", e)
            emptyList()
        }
    }

    /**
     * Directly searches or designs beautiful Argentine recipes using Gemini for a search query.
     */
    suspend fun searchArgentineRecipesDirectly(query: String, experienceLevel: String = "Amateur", specialty: String = "Casera"): List<Meal> {
        val apiKey = getApiKey() ?: return emptyList()

        val difficultyContext = when (experienceLevel.lowercase().trim()) {
            "principiante" -> "Propón recetas fáciles, rápidas de preparar, con pocos pasos explícitos y técnicas de cocción básicas aptas para un principiante en la cocina."
            "amateur" -> "Propón recetas clásicas caseras, tradicionales y familiares, con instrucciones que sigan una preparación hogareña tradicional."
            "sous chef" -> "Propón recetas gourmet elaboradas. Las instrucciones deben requerir técnicas intermedias a avanzadas (como reducciones de vino, puntos de sellado exactos o mantecaturas), logrando un plato con toques creativos de autor."
            "chef ejecutivo" -> "Propón recetas de autor sofisticadas, de la más alta cocina gourmet argentina contemporánea (estilo restaurante premium). Las instrucciones deben incluir técnicas complejas (emulsiones refinadas, reducciones al malbec satinadas, deconstrucción o texturas), con sugerencias artísticas de emplatado y presentación elegante de élite."
            else -> "Propón recetas adaptadas al nivel de dificultad clásica del chef."
        }

        val specialtyContext = when (specialty.lowercase().trim()) {
            "italiana" -> "Enfócate fuertemente en dar un estilo italiano/rioplatense al plato."
            "saludable" -> "Enfócate fuertemente en platos saludables, nutritivos o ligeros."
            "pastelería" -> "Oriéntalo a postres, panificados finos o preparaciones dulces de pastelería."
            "rápida y fácil" -> "Prioriza preparaciones rápidas (minutas prestigiosas) y eficaces."
            else -> "Enfócate en recetas criollas y caseras de alta cocina nacional."
        }

        val systemPrompt = """
            You are an expert master chef specializing in Argentine and South American regional haute cuisine. 
            The user is searching for recipes or meals matching: '$query'.
            The user's experience level is: '$experienceLevel'. 
            Therefore, you must: $difficultyContext
            
            The user's culinary specialty preference is: '$specialty'.
            Therefore, you must also adapt the recipes: $specialtyContext
            
            Your task is to generate a list of at least 15 delicious, authentic Argentinian or regional recipes (in Spanish/Castellano rioplatense) that match this query.
            
            CRITICAL RULES FOR RELEVANCE AND DIETARY COHERENCE:
            1. If the query refers to savory foods (like 'carne', 'pollo', 'papas', 'bife', 'asado', 'salado', 'guiso', 'pescado', 'verduras', etc.), you MUST NOT return any desserts, cakes, pastries, sweet dishes, flans, sweet puddings, or sugary items. The list must consist entirely of savory lunch or dinner options.
            2. If the query specifically relates to sweet desserts or pastries ('dulce', 'pastelería', 'postre', 'merengue', 'torta', 'alfajor', etc.), then you may return sweet recipes.
            3. Strictly respect the search term '$query'. If they search for 'carne' (meat) or 'pollo' (chicken), almost all of the returned dishes must contain that specific ingredient as a main or major component. Do not return random unrelated food.
            4. Each recipe's strMealThumb must be a relevant cooking food image URL from Unsplash.
            5. Return ONLY a valid JSON array of at least 15 objects. Do not include markdown code ticks.
            
            JSON Schema:
            [
              {
                "idMeal": "gem_search_1",
                "strMeal": "Recipe Name in Spanish",
                "strMealThumb": "https://images.unsplash.com/photo-...",
                "strCategory": "Category",
                "strArea": "Argentina",
                "strInstructions": "Step 1... Step 2... (strictly tailored to a $experienceLevel difficulty)",
                "ingredients": [
                   {"ing": "Ingrediente", "meas": "medida"}
                ]
              }
            ]
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(GeminiPart(text = "Search for food related to: $query under chef level $experienceLevel and specialty $specialty"))
                )
            ),
            generationConfig = GeminiGenerationConfig(
                responseMimeType = "application/json",
                temperature = 0.5
            ),
            systemInstruction = GeminiContent(
                parts = listOf(GeminiPart(text = systemPrompt))
            )
        )

        return try {
            val response = GeminiClient.api.generateContent(apiKey, request)
            val jsonText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (jsonText != null) {
                val cleanedJson = jsonText.trim()
                val array = JSONArray(cleanedJson)
                val list = mutableListOf<Meal>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val argIngs = obj.getJSONArray("ingredients")
                    val ingMaps = mutableListOf<Pair<String, String>>()
                    for (j in 0 until argIngs.length()) {
                        val ingObj = argIngs.getJSONObject(j)
                        ingMaps.add(Pair(ingObj.optString("ing"), ingObj.optString("meas")))
                    }

                    list.add(
                        Meal(
                            idMeal = obj.optString("idMeal", "gem_src_$i"),
                            strMeal = obj.optString("strMeal"),
                            strMealThumb = obj.optString("strMealThumb", "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500"),
                            strInstructions = obj.optString("strInstructions"),
                            strCategory = obj.optString("strCategory", "Tradicional"),
                            strArea = obj.optString("strArea", "Argentina"),
                            strIngredient1 = ingMaps.getOrNull(0)?.first, strMeasure1 = ingMaps.getOrNull(0)?.second,
                            strIngredient2 = ingMaps.getOrNull(1)?.first, strMeasure2 = ingMaps.getOrNull(1)?.second,
                            strIngredient3 = ingMaps.getOrNull(2)?.first, strMeasure3 = ingMaps.getOrNull(2)?.second,
                            strIngredient4 = ingMaps.getOrNull(3)?.first, strMeasure4 = ingMaps.getOrNull(3)?.second,
                            strIngredient5 = ingMaps.getOrNull(4)?.first, strMeasure5 = ingMaps.getOrNull(4)?.second,
                            strIngredient6 = ingMaps.getOrNull(5)?.first, strMeasure6 = ingMaps.getOrNull(5)?.second,
                            strIngredient7 = ingMaps.getOrNull(6)?.first, strMeasure7 = ingMaps.getOrNull(6)?.second,
                            strIngredient8 = ingMaps.getOrNull(7)?.first, strMeasure8 = ingMaps.getOrNull(7)?.second,
                            strIngredient9 = ingMaps.getOrNull(8)?.first, strMeasure9 = ingMaps.getOrNull(8)?.second,
                            strIngredient10 = ingMaps.getOrNull(9)?.first, strMeasure10 = ingMaps.getOrNull(9)?.second,
                            strIngredient11 = ingMaps.getOrNull(10)?.first, strMeasure11 = ingMaps.getOrNull(10)?.second,
                            strIngredient12 = ingMaps.getOrNull(11)?.first, strMeasure12 = ingMaps.getOrNull(11)?.second,
                            strIngredient13 = ingMaps.getOrNull(12)?.first, strMeasure13 = ingMaps.getOrNull(12)?.second,
                            strIngredient14 = ingMaps.getOrNull(13)?.first, strMeasure14 = ingMaps.getOrNull(13)?.second,
                            strIngredient15 = ingMaps.getOrNull(14)?.first, strMeasure15 = ingMaps.getOrNull(14)?.second
                        )
                    )
                }
                list
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e("GeminiService", "Failed to search recipes", e)
            emptyList()
        }
    }
}
