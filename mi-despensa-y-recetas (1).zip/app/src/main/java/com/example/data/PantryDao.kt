package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PantryDao {
    // Pantry Items
    @Query("SELECT * FROM pantry_items ORDER BY category ASC, name ASC")
    fun getAllPantryItems(): Flow<List<PantryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPantryItem(item: PantryItem)

    @Update
    suspend fun updatePantryItem(item: PantryItem)

    @Delete
    suspend fun deletePantryItem(item: PantryItem)

    @Query("DELETE FROM pantry_items WHERE id = :id")
    suspend fun deletePantryItemById(id: Int)

    // Meal History
    @Query("SELECT * FROM meal_history ORDER BY preparedAt DESC")
    fun getMealHistory(): Flow<List<MealHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMealHistory(history: MealHistory)

    @Query("DELETE FROM meal_history WHERE id = :id")
    suspend fun deleteMealHistoryById(id: Int)

    // Shopping Items
    @Query("SELECT * FROM shopping_items ORDER BY isCompleted ASC, category ASC, name ASC")
    fun getAllShoppingItems(): Flow<List<ShoppingItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingItem(item: ShoppingItem)

    @Update
    suspend fun updateShoppingItem(item: ShoppingItem)

    @Delete
    suspend fun deleteShoppingItem(item: ShoppingItem)

    @Query("DELETE FROM shopping_items WHERE id = :id")
    suspend fun deleteShoppingItemById(id: Int)

    @Query("DELETE FROM shopping_items WHERE isCompleted = 1")
    suspend fun clearCompletedShoppingItems()

    // Chef Profile
    @Query("SELECT * FROM chef_profile WHERE id = 1 LIMIT 1")
    fun getChefProfile(): Flow<ChefProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateChefProfile(profile: ChefProfile)

    // Weekly Meals Flow and Insert
    @Query("SELECT * FROM weekly_meals")
    fun getAllWeeklyMeals(): Flow<List<WeeklyMeal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateWeeklyMeal(meal: WeeklyMeal)

    @Query("DELETE FROM weekly_meals")
    suspend fun clearAllWeeklyMeals()

    // Saved Recipes (Option C)
    @Query("SELECT * FROM saved_recipes ORDER BY strMeal ASC")
    fun getAllSavedRecipes(): Flow<List<SavedRecipe>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedRecipe(recipe: SavedRecipe)

    @Query("DELETE FROM saved_recipes WHERE idMeal = :idMeal")
    suspend fun deleteSavedRecipeById(idMeal: String)
}
