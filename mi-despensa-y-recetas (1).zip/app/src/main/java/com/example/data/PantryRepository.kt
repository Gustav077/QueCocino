package com.example.data

import kotlinx.coroutines.flow.Flow

class PantryRepository(private val pantryDao: PantryDao) {

    // Pantry Streams and Methods
    val allPantryItems: Flow<List<PantryItem>> = pantryDao.getAllPantryItems()

    suspend fun insertPantryItem(item: PantryItem) {
        pantryDao.insertPantryItem(item)
    }

    suspend fun updatePantryItem(item: PantryItem) {
        pantryDao.updatePantryItem(item)
    }

    suspend fun deletePantryItem(item: PantryItem) {
        pantryDao.deletePantryItem(item)
    }

    suspend fun deletePantryItemById(id: Int) {
        pantryDao.deletePantryItemById(id)
    }

    // Meal History Streams and Methods
    val mealHistory: Flow<List<MealHistory>> = pantryDao.getMealHistory()

    suspend fun insertMealHistory(history: MealHistory) {
        pantryDao.insertMealHistory(history)
    }

    suspend fun deleteMealHistoryById(id: Int) {
        pantryDao.deleteMealHistoryById(id)
    }

    // Shopping List Streams and Methods
    val allShoppingItems: Flow<List<ShoppingItem>> = pantryDao.getAllShoppingItems()

    suspend fun insertShoppingItem(item: ShoppingItem) {
        pantryDao.insertShoppingItem(item)
    }

    suspend fun updateShoppingItem(item: ShoppingItem) {
        pantryDao.updateShoppingItem(item)
    }

    suspend fun deleteShoppingItem(item: ShoppingItem) {
        pantryDao.deleteShoppingItem(item)
    }

    suspend fun deleteShoppingItemById(id: Int) {
        pantryDao.deleteShoppingItemById(id)
    }

    suspend fun clearCompletedShoppingItems() {
        pantryDao.clearCompletedShoppingItems()
    }

    // Chef Profile Streams and Methods
    val chefProfile: Flow<ChefProfile?> = pantryDao.getChefProfile()

    suspend fun updateChefProfile(profile: ChefProfile) {
        pantryDao.insertOrUpdateChefProfile(profile)
    }

    // Weekly Meals Streams and Methods
    val allWeeklyMeals: Flow<List<WeeklyMeal>> = pantryDao.getAllWeeklyMeals()

    suspend fun updateWeeklyMeal(meal: WeeklyMeal) {
        pantryDao.insertOrUpdateWeeklyMeal(meal)
    }

    suspend fun clearAllWeeklyMeals() {
        pantryDao.clearAllWeeklyMeals()
    }

    // Saved Recipes (Option C)
    val allSavedRecipes: Flow<List<SavedRecipe>> = pantryDao.getAllSavedRecipes()

    suspend fun insertSavedRecipe(recipe: SavedRecipe) {
        pantryDao.insertSavedRecipe(recipe)
    }

    suspend fun deleteSavedRecipeById(idMeal: String) {
        pantryDao.deleteSavedRecipeById(idMeal)
    }
}
