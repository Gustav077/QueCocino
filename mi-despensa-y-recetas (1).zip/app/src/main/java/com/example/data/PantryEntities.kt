package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pantry_items")
data class PantryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val quantity: Double,
    val unit: String,
    val category: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "meal_history")
data class MealHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val recipeName: String,
    val preparedAt: Long = System.currentTimeMillis(),
    val imageUrl: String? = null,
    val ingredientsUsed: String = "" // Comma-separated list
)

@Entity(tableName = "shopping_items")
data class ShoppingItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val quantity: Double,
    val unit: String,
    val isCompleted: Boolean = false,
    val category: String = "Otros"
)

@Entity(tableName = "chef_profile")
data class ChefProfile(
    @PrimaryKey val id: Int = 1, // Single profile row
    val name: String = "Chef Aprendiz",
    val experienceLevel: String = "Amateur", // Principiante, Amateur, Profesional
    val specialty: String = "Casera",
    val servingsCount: Int = 2, // Default: 2 people
    val photoUri: String? = null
)

@Entity(tableName = "weekly_meals")
data class WeeklyMeal(
    @PrimaryKey val dayName: String, // "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"
    val lunchName: String = "",
    val lunchImageUrl: String? = null,
    val isLunchDone: Boolean = false,
    val dinnerName: String = "",
    val dinnerImageUrl: String? = null,
    val isDinnerDone: Boolean = false
)

@Entity(tableName = "saved_recipes")
data class SavedRecipe(
    @PrimaryKey val idMeal: String,
    val strMeal: String,
    val strMealThumb: String,
    val strInstructions: String?,
    val strCategory: String?,
    val strArea: String?,
    val strIngredient1: String? = null,
    val strIngredient2: String? = null,
    val strIngredient3: String? = null,
    val strIngredient4: String? = null,
    val strIngredient5: String? = null,
    val strIngredient6: String? = null,
    val strIngredient7: String? = null,
    val strIngredient8: String? = null,
    val strIngredient9: String? = null,
    val strIngredient10: String? = null,
    val strIngredient11: String? = null,
    val strIngredient12: String? = null,
    val strIngredient13: String? = null,
    val strIngredient14: String? = null,
    val strIngredient15: String? = null,
    val strMeasure1: String? = null,
    val strMeasure2: String? = null,
    val strMeasure3: String? = null,
    val strMeasure4: String? = null,
    val strMeasure5: String? = null,
    val strMeasure6: String? = null,
    val strMeasure7: String? = null,
    val strMeasure8: String? = null,
    val strMeasure9: String? = null,
    val strMeasure10: String? = null,
    val strMeasure11: String? = null,
    val strMeasure12: String? = null,
    val strMeasure13: String? = null,
    val strMeasure14: String? = null,
    val strMeasure15: String? = null
)


